# NewsHub Admin Setup and Configuration Guide

## Initial Admin Setup

### 1. Access the Admin Dashboard

After deployment, access the admin dashboard at:
- **Local**: http://localhost:3000/admin
- **Production**: https://admin.newshub.example.com

### 2. Default Admin Credentials

```
Email: admin@newshub.example.com
Password: admin123
```

⚠️ **Security Warning**: Change the default password immediately after first login!

### 3. Initial Configuration Steps

#### Step 1: Change Admin Password
1. Log in with default credentials
2. Navigate to Settings → Profile
3. Click "Change Password"
4. Enter current password (admin123)
5. Enter new strong password
6. Confirm new password
7. Click "Update Password"

#### Step 2: Configure Site Settings
1. Go to Settings → Site Configuration
2. Update the following settings:
   - **Site Name**: "NewsHub" (or your preferred name)
   - **Site URL**: Your production URL (e.g., https://app.newshub.example.com)
   - **Admin Email**: Your admin email address
   - **Contact Email**: Support email address
   - **Social Media Links**: Add your social media profiles
   - **SEO Settings**: Meta description, keywords, etc.
3. Click "Save Settings"

#### Step 3: Configure AI Services
1. Go to Settings → AI Configuration
2. Enter your Z-AI API key
3. Configure AI processing settings:
   - **Rewriting Tone**: Professional, Casual, Formal
   - **Content Length**: Short, Medium, Long
   - **Translation Languages**: Enable/disable languages
   - **Image Generation**: Enable/disable AI image generation
4. Click "Save Configuration"

## News Sources Configuration

### 1. Adding News Sources

#### Manual Addition
1. Navigate to Sources → Add Source
2. Fill in the source details:
   - **Name**: Source name (e.g., "TechCrunch")
   - **URL**: Source website URL (e.g., https://techcrunch.com)
   - **RSS Feed URL**: RSS feed URL if available
   - **Category**: Select category (Technology, Business, Sports, etc.)
   - **Language**: Source language
   - **Country**: Source country
   - **Scraping Frequency**: How often to scrape (e.g., "Every 30 minutes")
   - **Active**: Enable/disable source
3. Click "Add Source"

#### Bulk Import
1. Navigate to Sources → Import Sources
2. Upload CSV file with the following columns:
   ```
   name,url,rss_url,category,language,country,frequency
   ```
3. Click "Import Sources"

### 2. Configuring Scraping Rules

#### Per-Source Configuration
1. Go to Sources → Manage Sources
2. Click on a source to edit
3. Navigate to "Scraping Rules" tab
4. Configure:
   - **Article Selector**: CSS selector for article links
   - **Title Selector**: CSS selector for article title
   - **Content Selector**: CSS selector for article content
   - **Image Selector**: CSS selector for article images
   - **Date Selector**: CSS selector for publication date
   - **Author Selector**: CSS selector for author name
5. Click "Save Rules"

#### Global Scraping Settings
1. Go to Settings → Scraping Configuration
2. Configure global settings:
   - **User Agent**: Custom user agent string
   - **Request Timeout**: Request timeout in seconds
   - **Retry Attempts**: Number of retry attempts
   - **Rate Limit**: Requests per minute
   - **Respect robots.txt**: Enable/disable
   - **Follow redirects**: Enable/disable
3. Click "Save Settings"

### 3. Content Processing Rules

#### AI Processing Configuration
1. Go to Settings → Content Processing
2. Configure AI processing rules:
   - **Auto-rewrite**: Enable/disable automatic content rewriting
   - **Tone Adjustment**: Default tone for rewritten content
   - **Length Adjustment**: Default length for rewritten content
   - **Fact Checking**: Enable/disable automatic fact checking
   - **Translation**: Enable/disable automatic translation
   - **Image Processing**: Enable/disable AI image generation
3. Click "Save Settings"

#### Quality Control
1. Go to Settings → Quality Control
2. Configure quality thresholds:
   - **Minimum Content Length**: Minimum words per article
   - **Maximum Content Length**: Maximum words per article
   - **Spam Score Threshold**: Maximum allowed spam score
   - **Duplicate Content Threshold**: Maximum similarity percentage
   - **Fact Check Confidence**: Minimum confidence level
3. Click "Save Settings"

## Content Management

### 1. Article Review Queue

#### Review Process
1. Navigate to Content → Review Queue
2. Filter articles by status:
   - **Pending**: Articles awaiting review
   - **Approved**: Approved articles
   - **Rejected**: Rejected articles
   - **Published**: Published articles
3. Click on an article to review
4. Review the article content:
   - Check title and content quality
   - Verify images and media
   - Review AI-generated summaries
   - Check fact-checking results
5. Take action:
   - **Approve**: Publish the article
   - **Reject**: Reject with reason
   - **Edit**: Edit the article
   - **Request Rewrite**: Request AI rewrite

#### Bulk Actions
1. Select multiple articles using checkboxes
2. Choose bulk action:
   - **Approve Selected**
   - **Reject Selected**
   - **Delete Selected**
   - **Export Selected**

### 2. Published Content Management

#### Managing Published Articles
1. Navigate to Content → Published Articles
2. Filter and sort articles:
   - By date range
   - By category
   - By source
   - By status
3. Actions available:
   - **Edit**: Modify article content
   - **Unpublish**: Remove from public view
   - **Delete**: Permanently delete
   - **Share**: Share to social media
   - **Export**: Export article data

#### Content Analytics
1. Navigate to Analytics → Content Performance
2. View metrics:
   - **Page Views**: Number of views per article
   - **Engagement**: Time on page, scroll depth
   - **Social Shares**: Number of social media shares
   - **Comments**: Number of comments (if enabled)
   - **Conversion**: Newsletter signups from article

## User Management

### 1. Admin Users

#### Adding Admin Users
1. Navigate to Users → Admin Users
2. Click "Add Admin User"
3. Fill in user details:
   - **Name**: Full name
   - **Email**: Email address
   - **Role**: Admin role (Super Admin, Admin, Editor, Moderator)
   - **Permissions**: Select permissions
4. Click "Add User"

#### Managing Permissions
- **Super Admin**: Full system access
- **Admin**: Content and source management
- **Editor**: Content review and editing
- **Moderator**: Content moderation only

### 2. Newsletter Subscribers

#### Managing Subscribers
1. Navigate to Users → Newsletter Subscribers
2. View subscriber list:
   - Filter by subscription date
   - Filter by status (Active, Inactive, Unsubscribed)
   - Search by email
3. Actions:
   - **Export**: Export subscriber list
   - **Send Test Email**: Send test newsletter
   - **Unsubscribe**: Manually unsubscribe user

#### Newsletter Configuration
1. Navigate to Settings → Newsletter
2. Configure settings:
   - **From Name**: Sender name
   - **From Email**: Sender email
   - **Reply To**: Reply-to email
   - **Schedule**: Newsletter frequency
   - **Template**: Newsletter template
3. Click "Save Settings"

## Analytics and Monitoring

### 1. System Analytics

#### Dashboard Overview
1. Navigate to Analytics → Dashboard
2. View key metrics:
   - **Total Articles**: Number of articles processed
   - **Active Sources**: Number of active news sources
   - **Processing Rate**: Articles processed per hour
   - **Error Rate**: Processing error percentage
   - **System Health**: Overall system status

#### Performance Metrics
1. Navigate to Analytics → Performance
2. View performance data:
   - **Response Times**: API response times
   - **Database Performance**: Query execution times
   - **Cache Hit Rate**: Redis cache performance
   - **Queue Processing**: BullMQ queue statistics

### 2. Content Analytics

#### Source Performance
1. Navigate to Analytics → Sources
2. View source metrics:
   - **Articles Processed**: Articles per source
   - **Processing Time**: Average processing time
   - **Error Rate**: Error percentage per source
   - **Quality Score**: Average quality score

#### AI Processing Analytics
1. Navigate to Analytics → AI Processing
2. View AI metrics:
   - **Rewriting Success**: Success rate of content rewriting
   - **Translation Accuracy**: Translation quality metrics
   - **Fact Check Results**: Fact checking statistics
   - **Image Generation**: Image generation success rate

## Security Configuration

### 1. Security Settings

#### Authentication
1. Navigate to Settings → Security
2. Configure authentication:
   - **Session Timeout**: Session duration
   - **Password Policy**: Password requirements
   - **Two-Factor Authentication**: Enable/disable 2FA
   - **Login Attempts**: Maximum login attempts
3. Click "Save Settings"

#### API Security
1. Navigate to Settings → API Security
2. Configure API security:
   - **Rate Limiting**: API rate limits
   - **API Keys**: Manage API keys
   - **IP Whitelisting**: Allowed IP addresses
   - **CORS Settings**: Cross-origin settings
3. Click "Save Settings"

### 2. Backup and Recovery

#### Automated Backups
1. Navigate to Settings → Backups
2. Configure backup settings:
   - **Backup Frequency**: Daily, weekly, monthly
   - **Backup Retention**: Number of backups to keep
   - **Backup Location**: Storage location
   - **Email Notifications**: Backup completion notifications
3. Click "Save Settings"

#### Manual Backup
1. Navigate to Settings → Backups
2. Click "Create Backup Now"
3. Wait for backup completion
4. Download backup file if needed

## Troubleshooting

### Common Issues

#### Sources Not Scraping
1. Check source status in Sources → Manage Sources
2. Verify source URL is accessible
3. Check scraping rules configuration
4. Review error logs in Analytics → Logs

#### AI Processing Errors
1. Check AI service configuration in Settings → AI Configuration
2. Verify API key is valid
3. Check service status in Analytics → System Health
4. Review AI processing logs

#### Performance Issues
1. Check system resources in Analytics → Performance
2. Review database performance metrics
3. Check cache hit rates
4. Monitor queue processing times

#### Email Delivery Issues
1. Verify SMTP configuration in Settings → Email
2. Check email logs in Analytics → Logs
3. Test email configuration
4. Verify SPF/DKIM records

### Support Resources

#### Documentation
- Admin Guide: This document
- API Documentation: `/api/docs`
- Developer Guide: `docs/developer-guide.md`

#### Monitoring
- Grafana Dashboard: http://localhost:3002
- Prometheus Metrics: http://localhost:9090
- BullMQ Dashboard: http://localhost:3001

#### Logs
- Application Logs: `logs/app.log`
- Error Logs: `logs/error.log`
- Nginx Logs: `logs/nginx/`
- Docker Logs: `docker-compose logs`

## Best Practices

### 1. Source Management
- Start with a few high-quality sources
- Monitor source performance regularly
- Remove underperforming or problematic sources
- Diversify sources across categories

### 2. Content Quality
- Review AI-generated content before publishing
- Use fact-checking for important articles
- Maintain consistent tone and style
- Regularly update content processing rules

### 3. Security
- Change default passwords immediately
- Use strong, unique passwords
- Enable two-factor authentication
- Regularly update software and dependencies
- Monitor system logs for suspicious activity

### 4. Performance
- Monitor system resources regularly
- Optimize database queries
- Use caching effectively
- Scale resources as needed

### 5. Backup Strategy
- Perform regular automated backups
- Test backup restoration periodically
- Keep backups in multiple locations
- Document backup and recovery procedures

This comprehensive admin setup guide will help you configure and manage your NewsHub instance effectively. Remember to start with the basic configuration and gradually enable advanced features as you become familiar with the system.