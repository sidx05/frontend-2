# Production Environment Configuration Template

## Environment Variables

### Frontend Environment (.env.production)
```env
# Application Configuration
NEXT_PUBLIC_APP_NAME=NewsHub
NEXT_PUBLIC_APP_URL=https://app.newshub.example.com
NEXT_PUBLIC_API_URL=https://api.newshub.example.com
NEXT_PUBLIC_ADMIN_URL=https://admin.newshub.example.com

# Analytics and Monitoring
NEXT_PUBLIC_GOOGLE_ANALYTICS_ID=G-XXXXXXXXXX
NEXT_PUBLIC_SENTRY_DSN=https://your-sentry-dsn@sentry.io/project-id

# Feature Flags
NEXT_PUBLIC_ENABLE_NEWSLETTER=true
NEXT_PUBLIC_ENABLE_SOCIAL_SHARING=true
NEXT_PUBLIC_ENABLE_DARK_MODE=true
NEXT_PUBLIC_ENABLE_COMMENTS=false

# Security
NEXT_PUBLIC_RECAPTCHA_SITE_KEY=6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI

# Social Media Integration
NEXT_PUBLIC_FACEBOOK_APP_ID=your-facebook-app-id
NEXT_PUBLIC_TWITTER_HANDLE=newshub
NEXT_PUBLIC_LINKEDIN_COMPANY_ID=your-linkedin-company-id
```

### Backend Environment (.env.production)
```env
# Server Configuration
NODE_ENV=production
PORT=5001
HOST=0.0.0.0

# Database Configuration
MONGODB_URI=mongodb://mongodb:27017/newshub_production
MONGODB_TEST_URI=mongodb://mongodb:27017/newshub_test

# Redis Configuration
REDIS_URL=redis://redis:6379
REDIS_PASSWORD=your-redis-password

# JWT Configuration
JWT_SECRET=your-super-secret-jwt-key-change-in-production
JWT_EXPIRES_IN=7d
JWT_REFRESH_EXPIRES_IN=30d

# AI Service Configuration
ZAI_API_KEY=your-z-ai-api-key
ZAI_BASE_URL=https://api.z-ai.com/v1

# Email Configuration
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
SMTP_FROM=noreply@newshub.example.com

# Newsletter Configuration
NEWSLETTER_FROM=newsletter@newshub.example.com
NEWSLETTER_REPLY_TO=support@newshub.example.com

# Security Configuration
BCRYPT_ROUNDS=12
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100

# File Upload Configuration
MAX_FILE_SIZE=10485760
ALLOWED_FILE_TYPES=image/jpeg,image/png,image/webp,image/gif

# Logging Configuration
LOG_LEVEL=info
LOG_FILE=/var/log/newshub/app.log
ERROR_LOG_FILE=/var/log/newshub/error.log

# Monitoring Configuration
SENTRY_DSN=https://your-sentry-dsn@sentry.io/project-id
PROMETHEUS_METRICS_PORT=9090
HEALTH_CHECK_ENABLED=true
```

### Docker Environment (.env.docker)
```env
# Docker-specific configuration
COMPOSE_PROJECT_NAME=newshub
DOCKER_NETWORK=newshub-network

# Database Volumes
MONGODB_DATA_PATH=/var/lib/mongodb/data
REDIS_DATA_PATH=/var/lib/redis/data

# Logs
LOGS_PATH=/var/log/newshub

# SSL
SSL_CERT_PATH=/etc/ssl/certs
SSL_KEY_PATH=/etc/ssl/private

# Backup
BACKUP_PATH=/var/backups/newshub
BACKUP_RETENTION_DAYS=30
```

## Production Docker Compose

### docker-compose.prod.yml
```yaml
version: '3.8'

services:
  # Frontend (Next.js)
  frontend:
    build:
      context: .
      dockerfile: Dockerfile.frontend
      target: production
    container_name: newshub-frontend
    restart: unless-stopped
    environment:
      - NODE_ENV=production
      - NEXT_PUBLIC_APP_URL=https://app.newshub.example.com
      - NEXT_PUBLIC_API_URL=https://api.newshub.example.com
    volumes:
      - ./logs:/var/log/newshub
    networks:
      - newshub-network
    depends_on:
      - backend
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3000/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  # Backend (Node.js)
  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile
      target: production
    container_name: newshub-backend
    restart: unless-stopped
    environment:
      - NODE_ENV=production
      - MONGODB_URI=mongodb://mongodb:27017/newshub_production
      - REDIS_URL=redis://redis:6379
      - JWT_SECRET=your-super-secret-jwt-key-change-in-production
    volumes:
      - ./logs:/var/log/newshub
      - ./uploads:/var/uploads
    networks:
      - newshub-network
    depends_on:
      - mongodb
      - redis
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:5001/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  # MongoDB
  mongodb:
    image: mongo:6.0
    container_name: newshub-mongodb
    restart: unless-stopped
    environment:
      - MONGO_INITDB_ROOT_USERNAME=admin
      - MONGO_INITDB_ROOT_PASSWORD=your-mongodb-password
      - MONGO_INITDB_DATABASE=newshub_production
    volumes:
      - mongodb_data:/data/db
      - ./scripts/mongo-init.js:/docker-entrypoint-initdb.d/mongo-init.js:ro
    networks:
      - newshub-network
    ports:
      - "27017:27017"
    healthcheck:
      test: ["CMD", "mongosh", "--eval", "db.adminCommand('ping')"]
      interval: 30s
      timeout: 10s
      retries: 3

  # Redis
  redis:
    image: redis:7-alpine
    container_name: newshub-redis
    restart: unless-stopped
    command: redis-server --requirepass your-redis-password
    volumes:
      - redis_data:/data
    networks:
      - newshub-network
    ports:
      - "6379:6379"
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 30s
      timeout: 10s
      retries: 3

  # Nginx Reverse Proxy
  nginx:
    image: nginx:alpine
    container_name: newshub-nginx
    restart: unless-stopped
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/nginx.conf:ro
      - ./nginx/conf.d:/etc/nginx/conf.d:ro
      - ./ssl:/etc/ssl:ro
      - ./logs/nginx:/var/log/nginx
    networks:
      - newshub-network
    depends_on:
      - frontend
      - backend

  # BullMQ Dashboard (Optional)
  bullmq-dashboard:
    image: efenstakes/bullmq-dashboard:latest
    container_name: newshub-bullmq-dashboard
    restart: unless-stopped
    environment:
      - REDIS_HOST=redis
      - REDIS_PORT=6379
      - REDIS_PASSWORD=your-redis-password
    ports:
      - "3001:3000"
    networks:
      - newshub-network
    depends_on:
      - redis

  # Monitoring Stack
  prometheus:
    image: prom/prometheus:latest
    container_name: newshub-prometheus
    restart: unless-stopped
    ports:
      - "9090:9090"
    volumes:
      - ./monitoring/prometheus.yml:/etc/prometheus/prometheus.yml:ro
      - prometheus_data:/prometheus
    networks:
      - newshub-network
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
      - '--storage.tsdb.path=/prometheus'
      - '--web.console.libraries=/etc/prometheus/console_libraries'
      - '--web.console.templates=/etc/prometheus/consoles'
      - '--storage.tsdb.retention.time=200h'
      - '--web.enable-lifecycle'

  grafana:
    image: grafana/grafana:latest
    container_name: newshub-grafana
    restart: unless-stopped
    ports:
      - "3002:3000"
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=your-grafana-password
    volumes:
      - grafana_data:/var/lib/grafana
      - ./monitoring/grafana/dashboards:/etc/grafana/provisioning/dashboards:ro
      - ./monitoring/grafana/datasources:/etc/grafana/provisioning/datasources:ro
    networks:
      - newshub-network
    depends_on:
      - prometheus

volumes:
  mongodb_data:
    driver: local
  redis_data:
    driver: local
  prometheus_data:
    driver: local
  grafana_data:
    driver: local

networks:
  newshub-network:
    driver: bridge
    ipam:
      config:
        - subnet: 172.20.0.0/16
```

## Production Build Scripts

### build.sh
```bash
#!/bin/bash

set -e

echo "🚀 Starting NewsHub Production Build..."

# Check if Docker is running
if ! docker info > /dev/null 2>&1; then
    echo "❌ Docker is not running. Please start Docker and try again."
    exit 1
fi

# Create necessary directories
echo "📁 Creating directories..."
mkdir -p logs/nginx
mkdir -p ssl
mkdir -p uploads
mkdir -p backups

# Copy environment files
echo "📋 Setting up environment files..."
cp .env.example .env.production
cp backend/.env.example backend/.env.production

# Build Docker images
echo "🏗️  Building Docker images..."
docker-compose -f docker-compose.prod.yml build --no-cache

# Run database migrations
echo "🗄️  Running database migrations..."
docker-compose -f docker-compose.prod.yml up -d mongodb redis
sleep 10

# Wait for MongoDB to be ready
echo "⏳ Waiting for MongoDB to be ready..."
until docker-compose -f docker-compose.prod.yml exec mongodb mongosh --eval "db.adminCommand('ping')" &>/dev/null; do
    echo "Waiting for MongoDB..."
    sleep 2
done

# Initialize database
echo "🔧 Initializing database..."
docker-compose -f docker-compose.prod.yml exec backend npm run db:init

# Start all services
echo "🚀 Starting all services..."
docker-compose -f docker-compose.prod.yml up -d

# Wait for services to be ready
echo "⏳ Waiting for services to be ready..."
sleep 30

# Health checks
echo "🏥 Running health checks..."
if curl -f http://localhost:3000/health > /dev/null 2>&1; then
    echo "✅ Frontend is healthy"
else
    echo "❌ Frontend health check failed"
fi

if curl -f http://localhost:5001/health > /dev/null 2>&1; then
    echo "✅ Backend is healthy"
else
    echo "❌ Backend health check failed"
fi

echo "🎉 Production build completed successfully!"
echo "🌐 Frontend: http://localhost:3000"
echo "🔧 Backend: http://localhost:5001"
echo "📊 BullMQ Dashboard: http://localhost:3001"
echo "📈 Grafana: http://localhost:3002"
echo "📊 Prometheus: http://localhost:9090"
```

### deploy.sh
```bash
#!/bin/bash

set -e

echo "🚀 Starting NewsHub Production Deployment..."

# Pull latest changes
echo "📥 Pulling latest changes..."
git pull origin main

# Build and start services
echo "🏗️  Building and starting services..."
chmod +x build.sh
./build.sh

# Run tests
echo "🧪 Running tests..."
docker-compose -f docker-compose.prod.yml exec backend npm test

# Backup database
echo "💾 Creating database backup..."
docker-compose -f docker-compose.prod.yml exec mongodb mongodump --archive=/backups/mongodb-$(date +%Y%m%d-%H%M%S).gz --gzip

# Cleanup old containers and images
echo "🧹 Cleaning up old containers and images..."
docker system prune -f

echo "🎉 Deployment completed successfully!"
```

## Production Configuration Files

### nginx/nginx.conf
```nginx
user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log warn;
pid /var/run/nginx.pid;

events {
    worker_connections 1024;
    use epoll;
    multi_accept on;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    # Logging
    log_format main '$remote_addr - $remote_user [$time_local] "$request" '
                    '$status $body_bytes_sent "$http_referer" '
                    '"$http_user_agent" "$http_x_forwarded_for"';

    access_log /var/log/nginx/access.log main;

    # Basic Settings
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;
    server_tokens off;

    # Gzip Compression
    gzip on;
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types
        text/plain
        text/css
        text/xml
        text/javascript
        application/json
        application/javascript
        application/xml+rss
        application/atom+xml
        image/svg+xml;

    # Rate Limiting
    limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
    limit_req_zone $binary_remote_addr zone=login:10m rate=5r/m;

    # Include site configurations
    include /etc/nginx/conf.d/*.conf;
}
```

### monitoring/prometheus.yml
```yaml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

rule_files:
  - "alert_rules.yml"

alerting:
  alertmanagers:
    - static_configs:
        - targets:
          - alertmanager:9093

scrape_configs:
  - job_name: 'prometheus'
    static_configs:
      - targets: ['localhost:9090']

  - job_name: 'node-exporter'
    static_configs:
      - targets: ['node-exporter:9100']

  - job_name: 'newshub-backend'
    static_configs:
      - targets: ['backend:9090']
    metrics_path: '/metrics'

  - job_name: 'mongodb'
    static_configs:
      - targets: ['mongodb:27017']

  - job_name: 'redis'
    static_configs:
      - targets: ['redis:6379']
```

## Security Hardening

### security-hardening.sh
```bash
#!/bin/bash

echo "🔒 Applying security hardening..."

# Update system
sudo apt update && sudo apt upgrade -y

# Install security packages
sudo apt install -y fail2ban ufw unattended-upgrades

# Configure firewall
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow http
sudo ufw allow https
sudo ufw enable

# Configure Fail2Ban
sudo systemctl enable fail2ban
sudo systemctl start fail2ban

# Configure automatic security updates
sudo dpkg-reconfigure -plow unattended-upgrades

# Set up log rotation
sudo tee /etc/logrotate.d/newshub > /dev/null <<EOL
/var/log/newshub/*.log {
    daily
    missingok
    rotate 52
    compress
    delaycompress
    notifempty
    create 644 nginx nginx
    postrotate
        docker-compose -f /opt/newshub/docker-compose.prod.yml exec backend pkill -USR1 nginx
    endscript
}
EOL

echo "✅ Security hardening completed!"
```

## Backup Strategy

### backup.sh
```bash
#!/bin/bash

BACKUP_DIR="/var/backups/newshub"
DATE=$(date +%Y%m%d_%H%M%S)
RETENTION_DAYS=30

echo "🔄 Starting backup process..."

# Create backup directory
mkdir -p $BACKUP_DIR

# Backup MongoDB
echo "💾 Backing up MongoDB..."
docker-compose -f docker-compose.prod.yml exec mongodb mongodump \
    --archive=$BACKUP_DIR/mongodb_$DATE.gz \
    --gzip

# Backup Redis
echo "💾 Backing up Redis..."
docker-compose -f docker-compose.prod.yml exec redis redis-cli \
    --rdb $BACKUP_DIR/redis_$DATE.rdb

# Backup uploads
echo "💾 Backing up uploads..."
tar -czf $BACKUP_DIR/uploads_$DATE.tar.gz -C /opt/newshub uploads

# Clean old backups
echo "🧹 Cleaning old backups..."
find $BACKUP_DIR -type f -mtime +$RETENTION_DAYS -delete

echo "✅ Backup completed successfully!"
```

## Monitoring and Alerting

### alert_rules.yml
```yaml
groups:
  - name: NewsHub
    rules:
      - alert: HighCPUUsage
        expr: 100 - (avg by(instance) (irate(node_cpu_seconds_total{mode="idle"}[5m])) * 100) > 80
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "High CPU usage detected"
          description: "CPU usage is above 80% for 5 minutes"

      - alert: HighMemoryUsage
        expr: (node_memory_MemTotal_bytes - node_memory_MemAvailable_bytes) / node_memory_MemTotal_bytes * 100 > 80
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "High memory usage detected"
          description: "Memory usage is above 80% for 5 minutes"

      - alert: ServiceDown
        expr: up == 0
        for: 1m
        labels:
          severity: critical
        annotations:
          summary: "Service is down"
          description: "Service {{ $labels.instance }} is down"

      - alert: HighErrorRate
        expr: rate(http_requests_total{status=~"5.."}[5m]) > 0.1
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "High error rate detected"
          description: "Error rate is above 10% for 5 minutes"
```

This comprehensive production configuration template provides everything needed to deploy and run NewsHub in a production environment with proper security, monitoring, and backup strategies.