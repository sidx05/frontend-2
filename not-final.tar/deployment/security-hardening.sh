#!/bin/bash

echo "🔒 Applying NewsHub Production Security Hardening..."

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   echo "❌ This script must be run as root"
   exit 1
fi

# Update system
echo "📦 Updating system packages..."
apt update && apt upgrade -y

# Install security packages
echo "🛡️  Installing security packages..."
apt install -y \
    fail2ban \
    ufw \
    unattended-upgrades \
    logrotate \
    rsyslog \
    auditd \
    apparmor \
    apparmor-utils

# Configure firewall
echo "🔥 Configuring UFW firewall..."
ufw default deny incoming
ufw default allow outgoing
ufw allow ssh
ufw allow http
ufw allow https
ufw allow 3000/tcp    # Frontend
ufw allow 5001/tcp    # Backend API
ufw allow 3001/tcp    # BullMQ Dashboard
ufw allow 3002/tcp    # Grafana
ufw allow 9090/tcp    # Prometheus
ufw allow 9100/tcp    # Node Exporter
ufw enable

# Configure Fail2Ban
echo "🚫 Configuring Fail2Ban..."
cat > /etc/fail2ban/jail.local << 'EOF'
[DEFAULT]
bantime = 1h
findtime = 10m
maxretry = 5
backend = auto

[sshd]
enabled = true
port = ssh
filter = sshd
logpath = /var/log/auth.log
maxretry = 3

[nginx-http-auth]
enabled = true
filter = nginx-http-auth
port = http,https
logpath = /var/log/nginx/error.log
maxretry = 3

[nginx-limit-req]
enabled = true
filter = nginx-limit-req
port = http,https
logpath = /var/log/nginx/error.log
maxretry = 10

[nginx-botsearch]
enabled = true
filter = nginx-botsearch
port = http,https
logpath = /var/log/nginx/access.log
maxretry = 2

[recidive]
enabled = true
filter = recidive
logpath = /var/log/fail2ban.log
bantime = 1w
findtime = 1d
maxretry = 5
EOF

systemctl enable fail2ban
systemctl restart fail2ban

# Configure automatic security updates
echo "🔄 Configuring automatic security updates..."
cat > /etc/apt/apt.conf.d/50unattended-upgrades << 'EOF'
Unattended-Upgrade::Allowed-Origins {
    "${distro_id}:${distro_codename}";
    "${distro_id}:${distro_codename}-security";
    "${distro_id}ESM:${distro_codename}";
};

Unattended-Upgrade::Package-Blacklist {
};

Unattended-Upgrade::AutoFixInterruptedDpkg "true";
Unattended-Upgrade::MinimalSteps "true";
Unattended-Upgrade::InstallOnShutdown "false";
Unattended-Upgrade::Remove-Unused-Kernel-Packages "true";
Unattended-Upgrade::Remove-New-Unused-Dependencies "true";
Unattended-Upgrade::Remove-Unused-Dependencies "true";
Unattended-Upgrade::Automatic-Reboot "false";
Unattended-Upgrade::Automatic-Reboot-Time "02:00";
EOF

cat > /etc/apt/apt.conf.d/20auto-upgrades << 'EOF'
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Download-Upgradeable-Packages "1";
APT::Periodic::AutocleanInterval "7";
APT::Periodic::Unattended-Upgrade "1";
EOF

systemctl enable unattended-upgrades
systemctl start unattended-upgrades

# Configure AppArmor
echo "🔐 Configuring AppArmor..."
systemctl enable apparmor
systemctl start apparmor

# Enable AppArmor profiles
aa-enforce usr.bin.man
aa-enforce usr.sbin.rsyslogd
aa-enforce usr.sbin.tcpdump

# Configure system hardening
echo "⚙️  Configuring system hardening..."

# SSH hardening
cp /etc/ssh/sshd_config /etc/ssh/sshd_config.bak
cat > /etc/ssh/sshd_config << 'EOF'
Port 22
Protocol 2
HostKey /etc/ssh/ssh_host_rsa_key
HostKey /etc/ssh/ssh_host_ecdsa_key
HostKey /etc/ssh/ssh_host_ed25519_key
SyslogFacility AUTHPRIV
PermitRootLogin no
MaxAuthTries 3
MaxSessions 10
PasswordAuthentication yes
PermitEmptyPasswords no
ChallengeResponseAuthentication no
UsePAM yes
X11Forwarding no
PrintMotd no
AcceptEnv LANG LC_*
Subsystem sftp  /usr/lib/openssh/sftp-server
EOF

systemctl restart sshd

# Kernel parameters hardening
cat > /etc/sysctl.d/99-security-hardening.conf << 'EOF'
# IP Spoofing protection
net.ipv4.conf.all.rp_filter = 1
net.ipv4.conf.default.rp_filter = 1

# Ignore ICMP broadcast requests
net.ipv4.icmp_echo_ignore_broadcasts = 1

# Disable source packet routing
net.ipv4.conf.all.accept_source_route = 0
net.ipv6.conf.all.accept_source_route = 0
net.ipv4.conf.default.accept_source_route = 0
net.ipv6.conf.default.accept_source_route = 0

# Ignore send redirects
net.ipv4.conf.all.send_redirects = 0
net.ipv4.conf.default.send_redirects = 0

# Block SYN attacks
net.ipv4.tcp_max_syn_backlog = 2048
net.ipv4.tcp_synack_retries = 2
net.ipv4.tcp_syn_retries = 5

# Log Martians
net.ipv4.conf.all.log_martians = 1
net.ipv4.icmp_ignore_bogus_error_responses = 1

# Ignore ICMP redirects
net.ipv4.conf.all.accept_redirects = 0
net.ipv6.conf.all.accept_redirects = 0
net.ipv4.conf.default.accept_redirects = 0
net.ipv6.conf.default.accept_redirects = 0

# Ignore Directed Pings
net.ipv4.icmp_echo_ignore_all = 1

# Enable ExecShield protection
kernel.exec-shield = 1
kernel.randomize_va_space = 2

# TCP/IP stack hardening
net.ipv4.tcp_rfc1337 = 1
net.ipv4.tcp_syncookies = 1
net.ipv4.tcp_max_syn_backlog = 2048
net.ipv4.tcp_synack_retries = 2
net.ipv4.tcp_syn_retries = 5

# IPv6 hardening
net.ipv6.conf.all.router_solicitations = 0
net.ipv6.conf.default.router_solicitations = 0
net.ipv6.conf.all.accept_ra_rtr_pref = 0
net.ipv6.conf.default.accept_ra_rtr_pref = 0
net.ipv6.conf.all.accept_ra_pinfo = 0
net.ipv6.conf.default.accept_ra_pinfo = 0
net.ipv6.conf.all.accept_redirects = 0
net.ipv6.conf.default.accept_redirects = 0
net.ipv6.conf.all.accept_source_route = 0
net.ipv6.conf.default.accept_source_route = 0

# Filesystem hardening
fs.protected_hardlinks = 1
fs.protected_symlinks = 1
EOF

sysctl -p /etc/sysctl.d/99-security-hardening.conf

# Configure secure file permissions
echo "🔒 Configuring secure file permissions..."

# Set proper permissions for sensitive files
chmod 600 /etc/ssh/sshd_config
chmod 600 /etc/fail2ban/jail.local
chmod 644 /etc/sysctl.d/99-security-hardening.conf

# Remove unnecessary services
echo "🗑️  Removing unnecessary services..."
systemctl disable telnet.socket
systemctl disable rsh.socket
systemctl disable rexec.socket
systemctl disable rpcbind.socket
systemctl disable nfs-server
systemctl disable smbd
systemctl disable nmbd

# Configure log rotation
echo "📊 Configuring log rotation..."
cat > /etc/logrotate.d/newshub << 'EOF'
/var/log/newshub/*.log {
    daily
    missingok
    rotate 52
    compress
    delaycompress
    notifempty
    create 644 root root
    postrotate
        docker-compose -f /opt/newshub/docker-compose.prod.yml exec backend pkill -USR1 node
    endscript
}

/var/log/nginx/*.log {
    daily
    missingok
    rotate 52
    compress
    delaycompress
    notifempty
    create 644 nginx nginx
    postrotate
        docker-compose -f /opt/newshub/docker-compose.prod.yml exec nginx nginx -s reload
    endscript
}
EOF

# Configure auditd
echo "🔍 Configuring auditd..."
cat > /etc/audit/rules.d/audit.rules << 'EOF'
# Remove any existing rules
-D

# Buffer size
-b 8192

# Failure mode
-f 1

# Monitor file access
-a always,exit -F arch=b64 -S open,openat,openat2 -F exit=-EACCES -k access
-a always,exit -F arch=b64 -S open,openat,openat2 -F exit=-EPERM -k access

# Monitor successful file access
-a always,exit -F arch=b64 -S open,openat,openat2 -F success=1 -k success

# Monitor execution
-a always,exit -F arch=b64 -S execve -k exec

# Monitor system calls
-a always,exit -F arch=b64 -S bind,connect -k network

# Monitor changes to system files
-w /etc/passwd -p wa -k identity
-w /etc/group -p wa -k identity
-w /etc/shadow -p wa -k identity
-w /etc/sudoers -p wa -k identity
-w /etc/ssh/sshd_config -p wa -k sshd_config

# Monitor Docker
-w /var/lib/docker -p wa -k docker
-w /etc/docker -p wa -k docker
-w /etc/default/docker -p wa -k docker

# Make the rules persistent
-e
EOF

systemctl enable auditd
systemctl restart auditd

# Configure Docker security
echo "🐳 Configuring Docker security..."
cat > /etc/docker/daemon.json << 'EOF'
{
  "icc": false,
  "userland-proxy": false,
  "live-restore": true,
  "no-new-privileges": true,
  "default-ulimits": {
    "nofile": {
      "Name": "nofile",
      "Hard": 64000,
      "Soft": 64000
    }
  },
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  },
  "default-runtime": "runc",
  "runtimes": {
    "runc": {
      "path": "runc"
    }
  }
}
EOF

systemctl restart docker

# Create security monitoring script
echo "📈 Creating security monitoring script..."
cat > /usr/local/bin/security-monitor.sh << 'EOF'
#!/bin/bash

# Security monitoring script for NewsHub
# This script checks for common security issues and alerts

LOG_FILE="/var/log/security-monitor.log"
ALERT_EMAIL="admin@newshub.example.com"

# Function to log messages
log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> $LOG_FILE
}

# Function to send alert
send_alert() {
    echo "$1" | mail -s "Security Alert - NewsHub" $ALERT_EMAIL
}

# Check for failed login attempts
FAILED_LOGINS=$(journalctl _SYSTEMD_UNIT=ssh.service --since "1 hour ago" | grep "Failed password" | wc -l)
if [ $FAILED_LOGINS -gt 10 ]; then
    log_message "High number of failed SSH login attempts: $FAILED_LOGINS"
    send_alert "High number of failed SSH login attempts detected: $FAILED_LOGINS"
fi

# Check disk space
DISK_USAGE=$(df / | tail -1 | awk '{print $5}' | sed 's/%//')
if [ $DISK_USAGE -gt 90 ]; then
    log_message "High disk usage: ${DISK_USAGE}%"
    send_alert "High disk usage detected: ${DISK_USAGE}%"
fi

# Check memory usage
MEMORY_USAGE=$(free | grep Mem | awk '{printf "%.0f", $3/$2 * 100}')
if [ $MEMORY_USAGE -gt 90 ]; then
    log_message "High memory usage: ${MEMORY_USAGE}%"
    send_alert "High memory usage detected: ${MEMORY_USAGE}%"
fi

# Check CPU usage
CPU_USAGE=$(top -bn1 | grep "Cpu(s)" | sed "s/.*, *\([0-9.]*\)%* id.*/\1/" | awk '{print 100 - $1}')
if (( $(echo "$CPU_USAGE > 90" | bc -l) )); then
    log_message "High CPU usage: ${CPU_USAGE}%"
    send_alert "High CPU usage detected: ${CPU_USAGE}%"
fi

# Check Docker container status
CONTAINER_DOWN=$(docker ps --filter "status=exited" | wc -l)
if [ $CONTAINER_DOWN -gt 1 ]; then
    log_message "Docker containers are down: $CONTAINER_DOWN"
    send_alert "Docker containers are down: $CONTAINER_DOWN"
fi

# Check for suspicious processes
SUSPICIOUS_PROCESSES=$(ps aux | grep -E '(nc|netcat|nmap|tcpdump|wireshark)' | grep -v grep | wc -l)
if [ $SUSPICIOUS_PROCESSES -gt 0 ]; then
    log_message "Suspicious processes detected: $SUSPICIOUS_PROCESSES"
    send_alert "Suspicious processes detected: $SUSPICIOUS_PROCESSES"
fi

log_message "Security monitoring completed"
EOF

chmod +x /usr/local/bin/security-monitor.sh

# Add to crontab for regular monitoring
echo "0 */6 * * * /usr/local/bin/security-monitor.sh" | crontab -

# Create backup script
echo "💾 Creating backup script..."
cat > /usr/local/bin/newshub-backup.sh << 'EOF'
#!/bin/bash

# NewsHub backup script
BACKUP_DIR="/var/backups/newshub"
DATE=$(date +%Y%m%d_%H%M%S)
RETENTION_DAYS=30

# Create backup directory
mkdir -p $BACKUP_DIR

# Backup MongoDB
echo "Backing up MongoDB..."
docker-compose -f /opt/newshub/docker-compose.prod.yml exec -T mongodb mongodump \
    --archive=$BACKUP_DIR/mongodb_$DATE.gz \
    --gzip

# Backup Redis
echo "Backing up Redis..."
docker-compose -f /opt/newshub/docker-compose.prod.yml exec -T redis redis-cli \
    --rdb $BACKUP_DIR/redis_$DATE.rdb

# Backup configuration files
echo "Backing up configuration..."
tar -czf $BACKUP_DIR/config_$DATE.tar.gz \
    /opt/newshub/.env* \
    /opt/newshub/backend/.env* \
    /opt/newshub/nginx/ \
    /opt/newshub/monitoring/ \
    /etc/letsencrypt/ 2>/dev/null || true

# Clean old backups
echo "Cleaning old backups..."
find $BACKUP_DIR -type f -mtime +$RETENTION_DAYS -delete

echo "Backup completed: $DATE"
EOF

chmod +x /usr/local/bin/newshub-backup.sh

# Add to crontab for daily backups
echo "0 2 * * * /usr/local/bin/newshub-backup.sh" | crontab -

# Create system optimization script
echo "⚡ Creating system optimization script..."
cat > /usr/local/bin/system-optimize.sh << 'EOF'
#!/bin/bash

# System optimization script for NewsHub

# Clear system cache
sync; echo 1 > /proc/sys/vm/drop_caches
sync; echo 2 > /proc/sys/vm/drop_caches
sync; echo 3 > /proc/sys/vm/drop_caches

# Clear Docker cache
docker system prune -f

# Restart services if needed
systemctl restart docker
systemctl restart nginx

# Optimize MongoDB
docker-compose -f /opt/newshub/docker-compose.prod.yml exec -T mongodb mongosh --eval "db.runCommand({ compact: 'articles' })"
docker-compose -f /opt/newshub/docker-compose.prod.yml exec -T mongodb mongosh --eval "db.runCommand({ compact: 'sources' })"

# Optimize Redis
docker-compose -f /opt/newshub/docker-compose.prod.yml exec -T redis redis-cli BGREWRITEAOF

echo "System optimization completed"
EOF

chmod +x /usr/local/bin/system-optimize.sh

# Add to crontab for weekly optimization
echo "0 3 * * 0 /usr/local/bin/system-optimize.sh" | crontab -

echo "✅ Security hardening completed successfully!"
echo ""
echo "📋 Security Summary:"
echo "  - Firewall configured with UFW"
echo "  - Fail2Ban enabled for brute force protection"
echo "  - Automatic security updates configured"
echo "  - AppArmor profiles enabled"
echo "  - System hardening applied"
echo "  - Secure file permissions set"
echo "  - Audit logging enabled"
echo "  - Docker security configured"
echo "  - Security monitoring script created"
echo "  - Backup script created"
echo "  - System optimization script created"
echo ""
echo "🔑 Next Steps:"
echo "  1. Reboot the system to apply all changes"
echo "  2. Test all services after reboot"
echo "  3. Monitor security logs regularly"
echo "  4. Review backup configurations"
echo "  5. Set up monitoring alerts"
echo ""
echo "⚠️  Important:"
echo "  - Review all security configurations"
echo "  - Test backup restoration process"
echo "  - Monitor system performance"
echo "  - Keep system updated regularly"