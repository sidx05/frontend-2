# SSL and Domain Configuration Guide

## Prerequisites
- Registered domain name (e.g., newshub.example.com)
- Server with public IP address
- Root access to the server

## Step 1: DNS Configuration

### A Record Setup
Point your domain to your server's IP address:

```bash
# Example DNS records
A    newshub.example.com    192.168.1.100
A    www.newshub.example.com 192.168.1.100
```

### Subdomain Configuration
For production, we recommend using subdomains for different services:

```bash
# Main application
A    app.newshub.example.com    192.168.1.100

# Admin dashboard
A    admin.newshub.example.com  192.168.1.100

# API endpoints
A    api.newshub.example.com    192.168.1.100

# Monitoring
A    monitor.newshub.example.com 192.168.1.100
```

## Step 2: SSL Certificate Setup

### Option 1: Let's Encrypt (Recommended for Production)

```bash
# Install Certbot
sudo apt update
sudo apt install certbot python3-certbot-nginx

# Request SSL certificates
sudo certbot --nginx -d app.newshub.example.com -d www.app.newshub.example.com
sudo certbot --nginx -d admin.newshub.example.com
sudo certbot --nginx -d api.newshub.example.com
sudo certbot --nginx -d monitor.newshub.example.com
```

### Option 2: Self-signed Certificate (Development Only)

```bash
# Generate self-signed certificate
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
    -keyout /etc/ssl/private/newshub.key \
    -out /etc/ssl/certs/newshub.crt \
    -subj "/C=US/ST=California/L=San Francisco/O=NewsHub/CN=newshub.example.com"
```

## Step 3: Nginx Configuration

### Main Application Configuration
```nginx
# /etc/nginx/sites-available/app.newshub.example.com
server {
    listen 80;
    server_name app.newshub.example.com www.app.newshub.example.com;
    
    # Redirect to HTTPS
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name app.newshub.example.com www.app.newshub.example.com;
    
    # SSL Configuration
    ssl_certificate /etc/letsencrypt/live/app.newshub.example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/app.newshub.example.com/privkey.pem;
    
    # Security Headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    add_header Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self' data:; connect-src 'self' wss: https:;" always;
    
    # SSL Optimization
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-RSA-AES128-SHA256:ECDHE-RSA-AES256-SHA384;
    ssl_prefer_server_ciphers off;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;
    
    # Gzip Compression
    gzip on;
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;
    
    # Rate Limiting
    limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
    limit_req zone=api burst=20 nodelay;
    
    # Proxy to Next.js Application
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        
        # Timeouts
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
    
    # Static Files Caching
    location /_next/static/ {
        alias /var/www/newshub/.next/static/;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
    
    # Health Check
    location /health {
        access_log off;
        return 200 "healthy\n";
        add_header Content-Type text/plain;
    }
}
```

### Admin Dashboard Configuration
```nginx
# /etc/nginx/sites-available/admin.newshub.example.com
server {
    listen 80;
    server_name admin.newshub.example.com;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name admin.newshub.example.com;
    
    # SSL Configuration
    ssl_certificate /etc/letsencrypt/live/admin.newshub.example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/admin.newshub.example.com/privkey.pem;
    
    # Additional Security for Admin
    auth_basic "Admin Area";
    auth_basic_user_file /etc/nginx/.htpasswd;
    
    # IP Whitelisting (Optional)
    # allow 192.168.1.0/24;
    # deny all;
    
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

### API Configuration
```nginx
# /etc/nginx/sites-available/api.newshub.example.com
server {
    listen 80;
    server_name api.newshub.example.com;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name api.newshub.example.com;
    
    # SSL Configuration
    ssl_certificate /etc/letsencrypt/live/api.newshub.example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.newshub.example.com/privkey.pem;
    
    # API Security
    limit_req_zone $binary_remote_addr zone=api_limit:10m rate=30r/m;
    limit_req zone=api_limit burst=10 nodelay;
    
    # CORS Headers
    add_header Access-Control-Allow-Origin "https://app.newshub.example.com" always;
    add_header Access-Control-Allow-Methods "GET, POST, PUT, DELETE, OPTIONS" always;
    add_header Access-Control-Allow-Headers "Origin, X-Requested-With, Content-Type, Accept, Authorization" always;
    
    location / {
        proxy_pass http://localhost:5001;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # API Timeouts
        proxy_connect_timeout 30s;
        proxy_send_timeout 30s;
        proxy_read_timeout 30s;
    }
}
```

## Step 4: Enable Sites

```bash
# Enable sites
sudo ln -s /etc/nginx/sites-available/app.newshub.example.com /etc/nginx/sites-enabled/
sudo ln -s /etc/nginx/sites-available/admin.newshub.example.com /etc/nginx/sites-enabled/
sudo ln -s /etc/nginx/sites-available/api.newshub.example.com /etc/nginx/sites-enabled/

# Test configuration
sudo nginx -t

# Reload Nginx
sudo systemctl reload nginx
```

## Step 5: SSL Auto-renewal

```bash
# Test auto-renewal
sudo certbot renew --dry-run

# Add to crontab
echo "0 12 * * * /usr/bin/certbot renew --quiet" | sudo crontab -
```

## Step 6: Security Hardening

### Firewall Configuration
```bash
# Install UFW
sudo apt install ufw

# Configure firewall
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow http
sudo ufw allow https
sudo ufw enable
```

### Fail2Ban Setup
```bash
# Install Fail2Ban
sudo apt install fail2ban

# Create Nginx configuration
sudo tee /etc/fail2ban/jail.local > /dev/null <<EOL
[nginx-http-auth]
enabled = true
filter = nginx-http-auth
port = http,https
logpath = /var/log/nginx/error.log

[nginx-limit-req]
enabled = true
filter = nginx-limit-req
port = http,https
logpath = /var/log/nginx/error.log
maxretry = 10

[nginx-botsearch]
enabled = true
filter = nginx-botsearch
port = http,https
logpath = /var/log/nginx/access.log
maxretry = 2
EOL

# Restart Fail2Ban
sudo systemctl restart fail2ban
```

## Verification

### Test SSL Configuration
```bash
# Test SSL certificate
openssl s_client -connect app.newshub.example.com:443 -servername app.newshub.example.com

# SSL Labs Test
# Visit: https://www.ssllabs.com/ssltest/
```

### Test Application
```bash
# Test main application
curl -I https://app.newshub.example.com

# Test API
curl -I https://api.newshub.example.com/health

# Test admin dashboard
curl -I https://admin.newshub.example.com
```

## Troubleshooting

### Common Issues
1. **SSL Certificate Errors**: Check certificate paths and permissions
2. **Nginx Configuration Errors**: Use `nginx -t` to test configuration
3. **DNS Propagation**: Use `dig app.newshub.example.com` to verify DNS
4. **Firewall Issues**: Check UFW status with `sudo ufw status`

### Log Locations
- Nginx Access Log: `/var/log/nginx/access.log`
- Nginx Error Log: `/var/log/nginx/error.log`
- Certbot Log: `/var/log/letsencrypt/letsencrypt.log`
- Fail2Ban Log: `/var/log/fail2ban.log`