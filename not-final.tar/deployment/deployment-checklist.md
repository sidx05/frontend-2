# NewsHub Production Deployment Checklist & Runbook

## 🚀 Pre-Deployment Checklist

### ✅ System Requirements
- [ ] **Server Requirements**:
  - [ ] Ubuntu 20.04 LTS or 22.04 LTS
  - [ ] Minimum 4GB RAM (8GB recommended)
  - [ ] Minimum 2 CPU cores (4 cores recommended)
  - [ ] Minimum 50GB disk space (100GB recommended)
  - [ ] Public IP address
  - [ ] Root access or sudo privileges

- [ ] **Domain Requirements**:
  - [ ] Registered domain name
  - [ ] DNS A records configured
  - [ ] SSL certificates ready or Let's Encrypt access

- [ ] **Software Requirements**:
  - [ ] Docker and Docker Compose installed
  - [ ] Git installed
  - [ ] curl installed
  - [ ] Text editor (nano/vim) available

### ✅ Configuration Files
- [ ] **Environment Variables**:
  - [ ] `.env.production` created and configured
  - [ ] `backend/.env.production` created and configured
  - [ ] All sensitive values replaced with actual values
  - [ ] JWT secrets changed from defaults
  - [ ] Database passwords changed from defaults
  - [ ] API keys configured

- [ ] **SSL Certificates**:
  - [ ] SSL certificates obtained or ready to generate
  - [ ] Certificate paths configured in Nginx
  - [ ] Certificate renewal configured

- [ ] **Database Configuration**:
  - [ ] MongoDB connection string configured
  - [ ] Redis connection string configured
  - [ ] Database initialization script ready

### ✅ Security Configuration
- [ ] **Firewall**:
  - [ ] UFW installed and enabled
  - [ ] Required ports opened (80, 443, 22)
  - [ ] Unnecessary ports closed

- [ ] **SSH Security**:
  - [ ] Root login disabled
  - [ ] Password authentication disabled (key-based auth preferred)
  - [ ] SSH port changed from default (optional)
  - [ ] Fail2Ban configured

- [ ] **System Hardening**:
  - [ ] System packages updated
  - [ ] Automatic security updates enabled
  - [ ] AppArmor enabled
  - [ ] Audit logging configured

### ✅ Application Configuration
- [ ] **AI Services**:
  - [ ] Z-AI API key configured
  - [ ] AI processing settings configured
  - [ ] Image generation settings configured

- [ ] **Email Configuration**:
  - [ ] SMTP settings configured
  - [ ] Email templates ready
  - [ ] Newsletter configuration complete

- [ ] **Monitoring**:
  - [ ] Prometheus configuration ready
  - [ ] Grafana dashboards configured
  - [ ] Alert rules defined

## 🚀 Deployment Process

### Step 1: Server Preparation
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install required packages
sudo apt install -y docker.io docker-compose git curl nginx

# Add user to docker group
sudo usermod -aG docker $USER

# Create application directory
sudo mkdir -p /opt/newshub
sudo chown $USER:$USER /opt/newshub

# Clone repository
git clone https://github.com/your-username/newshub.git /opt/newshub
cd /opt/newshub
```

### Step 2: SSL Certificate Setup
```bash
# Install Certbot
sudo apt install -y certbot python3-certbot-nginx

# Request SSL certificates
sudo certbot --nginx -d app.newshub.example.com -d www.app.newshub.example.com
sudo certbot --nginx -d admin.newshub.example.com
sudo certbot --nginx -d api.newshub.example.com

# Copy certificates to project
sudo cp -r /etc/letsencrypt/live/app.newshub.example.com ./ssl/
sudo cp -r /etc/letsencrypt/live/admin.newshub.example.com ./ssl/
sudo cp -r /etc/letsencrypt/live/api.newshub.example.com ./ssl/
```

### Step 3: Configuration Setup
```bash
# Copy environment templates
cp .env.example .env.production
cp backend/.env.example backend/.env.production

# Edit environment files
nano .env.production
nano backend/.env.production

# Create necessary directories
mkdir -p logs/nginx ssl uploads backups monitoring/grafana/{dashboards,datasources}
```

### Step 4: Security Hardening
```bash
# Run security hardening script
chmod +x deployment/security-hardening.sh
sudo ./deployment/security-hardening.sh

# Reboot system
sudo reboot
```

### Step 5: Application Deployment
```bash
# After reboot, navigate to project directory
cd /opt/newshub

# Run build script
chmod +x build.sh
./build.sh

# Verify all services are running
docker-compose -f docker-compose.prod.yml ps
```

### Step 6: Post-Deployment Configuration
```bash
# Access admin dashboard
# URL: https://admin.newshub.example.com
# Default credentials: admin@newshub.example.com / admin123

# Change admin password immediately
# Configure site settings
# Add news sources
# Configure AI services
# Set up newsletter
# Configure monitoring alerts
```

## 🚀 Post-Deployment Checklist

### ✅ Service Verification
- [ ] **Frontend Service**:
  - [ ] Accessible at https://app.newshub.example.com
  - [ ] All pages loading correctly
  - [ ] Responsive design working
  - [ ] Dark mode functioning
  - [ ] Newsletter subscription working

- [ ] **Backend API**:
  - [ ] Accessible at https://api.newshub.example.com
  - [ ] API documentation accessible
  - [ ] Health endpoint returning 200
  - [ ] Authentication working
  - [ ] Rate limiting active

- [ ] **Admin Dashboard**:
  - [ ] Accessible at https://admin.newshub.example.com
  - [ ] Login working with new credentials
  - [ ] All admin panels accessible
  - [ ] Source management working
  - [ ] Content review queue working

- [ ] **Database Services**:
  - [ ] MongoDB running and accessible
  - [ ] Redis running and accessible
  - [ ] Data persistence working
  - [ ] Backup system working

### ✅ Monitoring Verification
- [ ] **Prometheus**:
  - [ ] Accessible at http://localhost:9090
  - [ ] All targets up and scraping
  - [ ] Metrics collecting correctly
  - [ ] Alert rules active

- [ ] **Grafana**:
  - [ ] Accessible at http://localhost:3002
  - [ ] Dashboards loaded
  - [ ] Data sources connected
  - [ ] Alerts configured

- [ ] **BullMQ Dashboard**:
  - [ ] Accessible at http://localhost:3001
  - [ ] Queue status visible
  - [ ] Job processing working

### ✅ Security Verification
- [ ] **SSL/TLS**:
  - [ ] All services using HTTPS
  - [ ] SSL certificates valid
  - [ ] HSTS headers present
  - [ ] Security headers configured

- [ ] **Firewall**:
  - [ ] UFW active and configured
  - [ ] Only required ports open
  - [ ] Intrusion detection working

- [ ] **Application Security**:
  - [ ] Default passwords changed
  - [ ] API keys secured
  - [ ] Environment variables protected
  - [ ] File permissions correct

### ✅ Performance Verification
- [ ] **Load Testing**:
  - [ ] Frontend loading under 3 seconds
  - [ ] API response time under 500ms
  - [ ] Database queries optimized
  - [ ] Cache hit rate > 80%

- [ ] **Resource Usage**:
  - [ ] CPU usage < 70% under normal load
  - [ ] Memory usage < 70% under normal load
  - [ ] Disk usage < 80%
  - [ ] Network bandwidth adequate

## 🚀 Production Runbook

### 📋 Daily Tasks
- [ ] **System Health Check**:
  ```bash
  # Check service status
  docker-compose -f docker-compose.prod.yml ps
  
  # Check resource usage
  htop
  
  # Check disk space
  df -h
  
  # Check logs for errors
  docker-compose -f docker-compose.prod.yml logs --tail=100
  ```

- [ ] **Application Monitoring**:
  - [ ] Review Grafana dashboards
  - [ ] Check Prometheus alerts
  - [ ] Monitor error rates
  - [ ] Review performance metrics

- [ ] **Content Management**:
  - [ ] Review article queue
  - [ ] Approve/reject articles
  - [ ] Monitor source performance
  - [ ] Check AI processing quality

### 📋 Weekly Tasks
- [ ] **System Maintenance**:
  ```bash
  # Run system optimization
  /usr/local/bin/system-optimize.sh
  
  # Check for security updates
  sudo apt update && sudo apt list --upgradable
  
  # Review security logs
  sudo journalctl -u sshd --since "1 week ago"
  ```

- [ ] **Database Maintenance**:
  ```bash
  # Optimize MongoDB
  docker-compose -f docker-compose.prod.yml exec mongodb mongosh --eval "db.repairDatabase()"
  
  # Optimize Redis
  docker-compose -f docker-compose.prod.yml exec redis redis-cli BGREWRITEAOF
  ```

- [ ] **Backup Verification**:
  ```bash
  # Check backup status
  ls -la /var/backups/newshub/
  
  # Test backup restoration (monthly)
  ```

### 📋 Monthly Tasks
- [ ] **Security Audit**:
  - [ ] Review user access
  - [ ] Update passwords
  - [ ] Check SSL certificate expiry
  - [ ] Review firewall rules

- [ ] **Performance Review**:
  - [ ] Analyze usage patterns
  - [ ] Review scaling needs
  - [ ] Optimize configurations
  - [ ] Update monitoring thresholds

- [ ] **Content Strategy Review**:
  - [ ] Analyze content performance
  - [ ] Review source effectiveness
  - [ ] Update AI processing rules
  - [ ] Plan content improvements

### 📋 Quarterly Tasks
- [ ] **System Updates**:
  - [ ] Update Docker images
  - [ ] Update dependencies
  - [ ] Patch security vulnerabilities
  - [ ] Test updates in staging

- [ ] **Backup Testing**:
  - [ ] Full backup restoration test
  - [ ] Disaster recovery drill
  - [ ] Update backup procedures
  - [ ] Document lessons learned

- [ ] **Capacity Planning**:
  - [ ] Review resource usage
  - [ ] Plan for scaling
  - [ ] Budget for infrastructure
  - [ ] Update architecture if needed

## 🚀 Troubleshooting Guide

### 🔧 Common Issues

#### Service Not Starting
**Symptoms**: Docker containers failing to start
**Solution**:
```bash
# Check Docker logs
docker-compose -f docker-compose.prod.yml logs

# Check system resources
htop
df -h

# Restart services
docker-compose -f docker-compose.prod.yml restart

# Rebuild if necessary
docker-compose -f docker-compose.prod.yml build
```

#### Database Connection Issues
**Symptoms**: Application unable to connect to database
**Solution**:
```bash
# Check database status
docker-compose -f docker-compose.prod.yml exec mongodb mongosh --eval "db.adminCommand('ping')"
docker-compose -f docker-compose.prod.yml exec redis redis-cli ping

# Check connection strings
grep -r "MONGODB_URI\|REDIS_URL" .env*

# Restart database services
docker-compose -f docker-compose.prod.yml restart mongodb redis
```

#### SSL Certificate Issues
**Symptoms**: HTTPS not working, certificate errors
**Solution**:
```bash
# Check certificate status
sudo certbot certificates

# Renew certificates
sudo certbot renew

# Restart Nginx
docker-compose -f docker-compose.prod.yml restart nginx

# Check certificate paths
ls -la ssl/
```

#### High Resource Usage
**Symptoms**: High CPU, memory, or disk usage
**Solution**:
```bash
# Identify resource usage
htop
df -h
docker stats

# Restart services
docker-compose -f docker-compose.prod.yml restart

# Clear cache
sync; echo 1 > /proc/sys/vm/drop_caches

# Prune Docker
docker system prune -f
```

#### AI Processing Issues
**Symptoms**: AI services not working, slow processing
**Solution**:
```bash
# Check API key configuration
grep -r "ZAI_API_KEY" .env*

# Test API connectivity
curl -H "Authorization: Bearer YOUR_API_KEY" https://api.z-ai.com/v1/models

# Check AI service logs
docker-compose -f docker-compose.prod.yml logs backend
```

### 🔧 Emergency Procedures

#### Full System Outage
1. **Assess the situation**:
   ```bash
   # Check all services
   docker-compose -f docker-compose.prod.yml ps
   
   # Check system status
   systemctl status docker nginx
   
   # Check resource usage
   htop
   df -h
   ```

2. **Restart critical services**:
   ```bash
   # Restart all services
   docker-compose -f docker-compose.prod.yml restart
   
   # If that fails, rebuild and restart
   docker-compose -f docker-compose.prod.yml down
   docker-compose -f docker-compose.prod.yml up -d
   ```

3. **Restore from backup if needed**:
   ```bash
   # Find latest backup
   ls -la /var/backups/newshub/
   
   # Restore database
   docker-compose -f docker-compose.prod.yml exec mongodb mongorestore --archive=/path/to/backup.gz --gzip
   ```

#### Security Incident
1. **Isolate the system**:
   ```bash
   # Stop all services
   docker-compose -f docker-compose.prod.yml down
   
   # Block external access
   ufw deny in
   ```

2. **Assess the damage**:
   ```bash
   # Check logs
   sudo journalctl -u sshd --since "1 day ago"
   sudo tail -f /var/log/auth.log
   
   # Check for suspicious files
   find / -name "*.sh" -o -name "*.py" -o -name "*.pl" | grep -v "/usr\|/opt\|/var"
   ```

3. **Restore from clean backup**:
   ```bash
   # Restore from known good backup
   docker-compose -f docker-compose.prod.yml exec mongodb mongorestore --archive=/path/to/clean-backup.gz --gzip
   ```

4. **Hardening and recovery**:
   ```bash
   # Change all passwords
   # Update all API keys
   # Run security hardening script
   sudo ./deployment/security-hardening.sh
   ```

## 🚀 Contact Information

### 📞 Emergency Contacts
- **System Administrator**: admin@newshub.example.com
- **Developer Team**: dev@newshub.example.com
- **Security Team**: security@newshub.example.com

### 🌐 Important URLs
- **Main Application**: https://app.newshub.example.com
- **Admin Dashboard**: https://admin.newshub.example.com
- **API Documentation**: https://api.newshub.example.com/docs
- **Grafana Dashboard**: http://localhost:3002
- **Prometheus**: http://localhost:9090
- **BullMQ Dashboard**: http://localhost:3001

### 📚 Documentation
- **Admin Guide**: `deployment/admin-setup-guide.md`
- **API Documentation**: `docs/api.md`
- **Developer Guide**: `docs/developer-guide.md`
- **Security Guide**: `deployment/security-hardening.sh`

---

## 🎉 Deployment Complete!

Congratulations! You have successfully deployed NewsHub to production. 

### 📋 Final Reminders
- [ ] Monitor system performance for the first 24 hours
- [ ] Set up all monitoring alerts
- [ ] Test backup restoration process
- [ ] Document any custom configurations
- [ ] Schedule regular maintenance
- [ ] Keep documentation updated

### 🚀 Next Steps
1. **Go Live**: Make the site publicly accessible
2. **Monitor**: Keep an eye on performance and errors
3. **Optimize**: Continuously improve based on analytics
4. **Scale**: Prepare for increased traffic as needed
5. **Maintain**: Keep the system updated and secure

Your NewsHub instance is now ready for production use! 🎊