#!/bin/bash

set -e

echo "🚀 Starting NewsHub Production Build..."

# Check if Docker is running
if ! docker info > /dev/null 2>&1; then
    echo "❌ Docker is not running. Please start Docker and try again."
    exit 1
fi

# Create necessary directories
echo "📁 Creating directories..."
mkdir -p logs/nginx
mkdir -p ssl
mkdir -p uploads
mkdir -p backups
mkdir -p monitoring/grafana/dashboards
mkdir -p monitoring/grafana/datasources
mkdir -p scripts

# Create environment files if they don't exist
echo "📋 Setting up environment files..."
if [ ! -f .env.production ]; then
    cp .env.example .env.production
    echo "⚠️  Please edit .env.production with your production values"
fi

if [ ! -f backend/.env.production ]; then
    cp backend/.env.example backend/.env.production
    echo "⚠️  Please edit backend/.env.production with your production values"
fi

# Create MongoDB initialization script
echo "🗄️  Creating MongoDB initialization script..."
cat > scripts/mongo-init.js << 'EOF'
db = db.getSiblingDB('newshub_production');

// Create collections
db.createCollection('articles');
db.createCollection('sources');
db.createCollection('users');
db.createCollection('newsletters');
db.createCollection('scrapingjobs');

// Create indexes
db.articles.createIndex({ "title": "text", "content": "text" });
db.articles.createIndex({ "publishedAt": -1 });
db.articles.createIndex({ "source": 1 });
db.articles.createIndex({ "status": 1 });

db.sources.createIndex({ "url": 1 }, { unique: true });
db.sources.createIndex({ "isActive": 1 });

db.users.createIndex({ "email": 1 }, { unique: true });
db.users.createIndex({ "role": 1 });

db.newsletters.createIndex({ "email": 1 }, { unique: true });
db.newsletters.createIndex({ "isActive": 1 });

db.scrapingjobs.createIndex({ "status": 1 });
db.scrapingjobs.createIndex({ "createdAt": -1 });

// Create default admin user
db.users.insertOne({
    email: "admin@newshub.example.com",
    password: "$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LeZeUfkZMBs9kYZP6", // password: admin123
    role: "admin",
    isActive: true,
    createdAt: new Date(),
    updatedAt: new Date()
});

print("Database initialized successfully!");
EOF

# Create Nginx configuration
echo "🔧 Creating Nginx configuration..."
mkdir -p nginx/conf.d

cat > nginx/nginx.conf << 'EOF'
user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log warn;
pid /var/run/nginx.pid;

events {
    worker_connections 1024;
    use epoll;
    multi_accept on;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    # Logging
    log_format main '$remote_addr - $remote_user [$time_local] "$request" '
                    '$status $body_bytes_sent "$http_referer" '
                    '"$http_user_agent" "$http_x_forwarded_for"';

    access_log /var/log/nginx/access.log main;

    # Basic Settings
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;
    server_tokens off;

    # Gzip Compression
    gzip on;
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types
        text/plain
        text/css
        text/xml
        text/javascript
        application/json
        application/javascript
        application/xml+rss
        application/atom+xml
        image/svg+xml;

    # Rate Limiting
    limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
    limit_req_zone $binary_remote_addr zone=login:10m rate=5r/m;

    # Include site configurations
    include /etc/nginx/conf.d/*.conf;
}
EOF

cat > nginx/conf.d/app.conf << 'EOF'
server {
    listen 80;
    server_name app.newshub.example.com www.app.newshub.example.com;
    
    # Redirect to HTTPS
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name app.newshub.example.com www.app.newshub.example.com;
    
    # SSL Configuration (placeholder - replace with actual certs)
    ssl_certificate /etc/ssl/certs/newshub.crt;
    ssl_certificate_key /etc/ssl/private/newshub.key;
    
    # Security Headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    
    # SSL Optimization
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384;
    ssl_prefer_server_ciphers off;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;
    
    # Proxy to Next.js Application
    location / {
        proxy_pass http://frontend:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        
        # Timeouts
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
    
    # Static Files Caching
    location /_next/static/ {
        proxy_pass http://frontend:3000;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
    
    # Health Check
    location /health {
        access_log off;
        return 200 "healthy\n";
        add_header Content-Type text/plain;
    }
}
EOF

cat > nginx/conf.d/api.conf << 'EOF'
server {
    listen 80;
    server_name api.newshub.example.com;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name api.newshub.example.com;
    
    # SSL Configuration (placeholder - replace with actual certs)
    ssl_certificate /etc/ssl/certs/newshub.crt;
    ssl_certificate_key /etc/ssl/private/newshub.key;
    
    # API Security
    limit_req zone=api burst=10 nodelay;
    
    # CORS Headers
    add_header Access-Control-Allow-Origin "https://app.newshub.example.com" always;
    add_header Access-Control-Allow-Methods "GET, POST, PUT, DELETE, OPTIONS" always;
    add_header Access-Control-Allow-Headers "Origin, X-Requested-With, Content-Type, Accept, Authorization" always;
    
    location / {
        proxy_pass http://backend:5001;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # API Timeouts
        proxy_connect_timeout 30s;
        proxy_send_timeout 30s;
        proxy_read_timeout 30s;
    }
}
EOF

# Create Prometheus configuration
echo "📊 Creating Prometheus configuration..."
cat > monitoring/prometheus.yml << 'EOF'
global:
  scrape_interval: 15s
  evaluation_interval: 15s

rule_files:
  - "alert_rules.yml"

scrape_configs:
  - job_name: 'prometheus'
    static_configs:
      - targets: ['localhost:9090']

  - job_name: 'node-exporter'
    static_configs:
      - targets: ['node-exporter:9100']

  - job_name: 'newshub-backend'
    static_configs:
      - targets: ['backend:9090']
    metrics_path: '/metrics'

  - job_name: 'mongodb'
    static_configs:
      - targets: ['mongodb:27017']

  - job_name: 'redis'
    static_configs:
      - targets: ['redis:6379']
EOF

# Create Grafana datasource configuration
echo "📈 Creating Grafana configuration..."
cat > monitoring/grafana/datasources/prometheus.yml << 'EOF'
apiVersion: 1

datasources:
  - name: Prometheus
    type: prometheus
    access: proxy
    orgId: 1
    url: http://prometheus:9090
    basicAuth: false
    isDefault: true
    version: 1
    editable: false
EOF

# Build Docker images
echo "🏗️  Building Docker images..."
docker-compose -f docker-compose.prod.yml build --no-cache

# Run database services first
echo "🗄️  Starting database services..."
docker-compose -f docker-compose.prod.yml up -d mongodb redis

# Wait for MongoDB to be ready
echo "⏳ Waiting for MongoDB to be ready..."
until docker-compose -f docker-compose.prod.yml exec -T mongodb mongosh --eval "db.adminCommand('ping')" &>/dev/null; do
    echo "Waiting for MongoDB..."
    sleep 2
done

# Wait for Redis to be ready
echo "⏳ Waiting for Redis to be ready..."
until docker-compose -f docker-compose.prod.yml exec -T redis redis-cli ping &>/dev/null; do
    echo "Waiting for Redis..."
    sleep 2
done

# Start backend service
echo "🚀 Starting backend service..."
docker-compose -f docker-compose.prod.yml up -d backend

# Wait for backend to be ready
echo "⏳ Waiting for backend to be ready..."
until docker-compose -f docker-compose.prod.yml exec -T backend curl -f http://localhost:5001/health &>/dev/null; do
    echo "Waiting for backend..."
    sleep 2
done

# Start remaining services
echo "🚀 Starting remaining services..."
docker-compose -f docker-compose.prod.yml up -d frontend nginx bullmq-dashboard prometheus grafana node-exporter

# Wait for services to be ready
echo "⏳ Waiting for all services to be ready..."
sleep 30

# Health checks
echo "🏥 Running health checks..."

if curl -f http://localhost:3000/health > /dev/null 2>&1; then
    echo "✅ Frontend is healthy"
else
    echo "❌ Frontend health check failed"
fi

if curl -f http://localhost:5001/health > /dev/null 2>&1; then
    echo "✅ Backend is healthy"
else
    echo "❌ Backend health check failed"
fi

if curl -f http://localhost:9090/-/healthy > /dev/null 2>&1; then
    echo "✅ Prometheus is healthy"
else
    echo "❌ Prometheus health check failed"
fi

if curl -f http://localhost:3002/api/health > /dev/null 2>&1; then
    echo "✅ Grafana is healthy"
else
    echo "❌ Grafana health check failed"
fi

echo ""
echo "🎉 Production build completed successfully!"
echo ""
echo "🌐 Application URLs:"
echo "   Frontend: http://localhost:3000"
echo "   Backend API: http://localhost:5001"
echo "   BullMQ Dashboard: http://localhost:3001"
echo "   Grafana: http://localhost:3002"
echo "   Prometheus: http://localhost:9090"
echo ""
echo "📋 Next Steps:"
echo "   1. Configure your domain and SSL certificates"
echo "   2. Update environment files with your actual values"
echo "   3. Access the admin dashboard to configure news sources"
echo "   4. Set up monitoring and alerting"
echo ""
echo "⚠️  Important:"
echo "   - Default admin credentials: admin@newshub.example.com / admin123"
echo "   - Change all default passwords immediately"
echo "   - Configure SSL certificates for production"
echo "   - Set up proper DNS records"