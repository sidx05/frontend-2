#!/bin/bash

set -e

echo "🚀 Starting NewsHub Production Deployment..."

# Pull latest changes
echo "📥 Pulling latest changes..."
git pull origin main

# Stop existing services
echo "🛑 Stopping existing services..."
docker-compose -f docker-compose.prod.yml down

# Build and start services
echo "🏗️  Building and starting services..."
./build.sh

# Run tests
echo "🧪 Running tests..."
docker-compose -f docker-compose.prod.yml exec -T backend npm test

# Backup database
echo "💾 Creating database backup..."
BACKUP_FILE="backups/mongodb-$(date +%Y%m%d-%H%M%S).gz"
docker-compose -f docker-compose.prod.yml exec -T mongodb mongodump --archive=$BACKUP_FILE --gzip
echo "✅ Database backup created: $BACKUP_FILE"

# Cleanup old containers and images
echo "🧹 Cleaning up old containers and images..."
docker system prune -f

# Check service health
echo "🏥 Checking service health..."
sleep 10

if curl -f http://localhost:3000/health > /dev/null 2>&1; then
    echo "✅ Frontend is healthy"
else
    echo "❌ Frontend health check failed"
    exit 1
fi

if curl -f http://localhost:5001/health > /dev/null 2>&1; then
    echo "✅ Backend is healthy"
else
    echo "❌ Backend health check failed"
    exit 1
fi

echo ""
echo "🎉 Deployment completed successfully!"
echo ""
echo "📊 Service Status:"
docker-compose -f docker-compose.prod.yml ps