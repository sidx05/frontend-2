import { Router } from 'express';
import publicRoutes from './public.routes';
import authRoutes from './auth.routes';
import adminRoutes from './admin.routes';

export function setupRoutes(app: any) {
  // API version prefix
  const apiRouter = Router();
  
  // Public routes
  apiRouter.use('/public', publicRoutes);
  
  // Auth routes
  apiRouter.use('/auth', authRoutes);
  
  // Admin routes
  apiRouter.use('/admin', adminRoutes);
  
  // Mount API routes
  app.use('/api', apiRouter);
  
  // Root redirect to API docs
  app.get('/', (req, res) => {
    res.redirect('/api-docs');
  });
}