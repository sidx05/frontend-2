import Parser from 'rss-parser';
import axios from 'axios';
import * as cheerio from 'cheerio';
import crypto from 'crypto';
import { Source, Article, Category, JobLog } from '../models';
import { logger } from '../utils/logger';

export interface ScrapedArticle {
  title: string;
  summary: string;
  content: string;
  images: Array<{
    url: string;
    alt: string;
    caption?: string;
    width?: number;
    height?: number;
    source: 'scraped' | 'opengraph' | 'ai_generated';
  }>;
  category: string;
  tags: string[];
  author: string;
  lang: string;
  sourceUrl: string;
  publishedAt: Date;
  hash: string;
  openGraph?: {
    image?: string;
    title?: string;
    description?: string;
  };
}

export class ScrapingService {
  private rssParser: Parser;

  constructor() {
    this.rssParser = new Parser();
  }

  async scrapeAllSources() {
    try {
      logger.info('Starting scraping for all sources');
      
      const sources = await Source.find({ active: true });
      const results: any[] = [];

      for (const source of sources) {
        try {
          const sourceResults = await this.scrapeSource(source);
          results.push(...sourceResults);
          
          // Update last scraped timestamp
          await Source.findByIdAndUpdate(source._id, { lastScraped: new Date() });
        } catch (error) {
          logger.error(`Error scraping source ${source.name}:`, error);
        }
      }

      logger.info(`Scraping completed. Found ${results.length} articles`);
      return results;
    } catch (error) {
      logger.error('Scrape all sources error:', error);
      throw error;
    }
  }

  async scrapeSource(source: any) {
    try {
      logger.info(`Scraping source: ${source.name}`);
      
      const articles: ScrapedArticle[] = [];
      
      for (const rssUrl of source.rssUrls) {
        try {
          const feed = await this.rssParser.parseURL(rssUrl);
          
          for (const item of feed.items) {
            try {
              const scrapedArticle = await this.scrapeArticle(item, source);
              if (scrapedArticle) {
                articles.push(scrapedArticle);
              }
            } catch (error) {
              logger.error(`Error scraping article from ${source.name}:`, error);
            }
          }
        } catch (error) {
          logger.error(`Error parsing RSS feed ${rssUrl}:`, error);
        }
      }

      logger.info(`Scraped ${articles.length} articles from ${source.name}`);
      return articles;
    } catch (error) {
      logger.error(`Scrape source error for ${source.name}:`, error);
      throw error;
    }
  }

  async scrapeArticle(item: any, source: any): Promise<ScrapedArticle | null> {
    try {
      // Extract basic information
      const title = item.title || '';
      const link = item.link || '';
      const summary = item.contentSnippet || item.summary || '';
      const publishedAt = item.pubDate ? new Date(item.pubDate) : new Date();

      if (!title || !link) {
        return null;
      }

      // Fetch full article content
      const fullContent = await this.fetchArticleContent(link);
      
      // Extract Open Graph data
      const openGraphData = await this.extractOpenGraphData(link);
      
      // Extract images
      const images = this.extractImages(fullContent, link, openGraphData);
      
      // If no images found, try Open Graph image
      if (images.length === 0 && openGraphData.image) {
        images.push({
          url: openGraphData.image,
          alt: title,
          caption: 'Open Graph image',
          source: 'opengraph'
        });
      }
      
      // Generate hash for deduplication
      const hash = this.generateHash(title + summary + source._id.toString());
      
      // Check for duplicates
      const existingArticle = await Article.findOne({ hash });
      if (existingArticle) {
        logger.debug(`Duplicate article found: ${title}`);
        return null;
      }

      // Determine category
      const category = await this.determineCategory(title, summary, source.categories);
      
      // Extract tags
      const tags = this.extractTags(title, summary, fullContent);

      return {
        title,
        summary: summary.substring(0, 300),
        content: this.cleanContent(fullContent),
        images,
        category: category._id.toString(),
        tags,
        author: this.extractAuthor(fullContent) || source.name,
        lang: source.lang,
        sourceUrl: link,
        publishedAt,
        hash,
        openGraph: openGraphData
      };
    } catch (error) {
      logger.error('Scrape article error:', error);
      return null;
    }
  }

  private async fetchArticleContent(url: string): Promise<string> {
    try {
      const response = await axios.get(url, {
        timeout: 10000,
        headers: {
          'User-Agent': 'Mozilla/5.0 (compatible; NewsHub/1.0; +https://newshub.com)',
        },
      });

      const $ = cheerio.load(response.data);
      
      // Remove unwanted elements
      $('script, style, nav, header, footer, .ads, .advertisement, .comments').remove();
      
      // Try to find main content
      let content = '';
      
      // Common content selectors
      const contentSelectors = [
        'article',
        '.article',
        '.content',
        '.post-content',
        '.entry-content',
        '.story-content',
        'main',
        '.main-content',
        '#content',
      ];

      for (const selector of contentSelectors) {
        const element = $(selector);
        if (element.length > 0) {
          content = element.text();
          break;
        }
      }

      // If no specific content found, get body content
      if (!content) {
        content = $('body').text();
      }

      return this.cleanText(content);
    } catch (error) {
      logger.error(`Fetch article content error for ${url}:`, error);
      return '';
    }
  }

  private extractImages(html: string, baseUrl: string, openGraphData?: any): Array<{
    url: string;
    alt: string;
    caption?: string;
    width?: number;
    height?: number;
    source: 'scraped' | 'opengraph' | 'ai_generated';
  }> {
    try {
      const $ = cheerio.load(html);
      const images: Array<{
        url: string;
        alt: string;
        caption?: string;
        width?: number;
        height?: number;
        source: 'scraped' | 'opengraph' | 'ai_generated';
      }> = [];

      $('img').each((_, element) => {
        const src = $(element).attr('src');
        const alt = $(element).attr('alt') || 'Article image';
        const width = parseInt($(element).attr('width') || '0');
        const height = parseInt($(element).attr('height') || '0');
        
        if (src) {
          // Handle relative URLs
          const fullUrl = src.startsWith('http') ? src : new URL(src, baseUrl).href;
          
          // Skip very small images (likely icons or ads)
          if (width > 50 && height > 50 || (width === 0 && height === 0)) {
            images.push({
              url: fullUrl,
              alt,
              width: width > 0 ? width : undefined,
              height: height > 0 ? height : undefined,
              source: 'scraped'
            });
          }
        }
      });

      // Return unique images, limit to first 5
      return [...new Map(images.map(img => [img.url, img])).values()].slice(0, 5);
    } catch (error) {
      logger.error('Extract images error:', error);
      return [];
    }
  }

  private generateHash(content: string): string {
    return crypto.createHash('sha256').update(content).digest('hex');
  }

  private async extractOpenGraphData(url: string): Promise<{
    image?: string;
    title?: string;
    description?: string;
  }> {
    try {
      const response = await axios.get(url, {
        timeout: 10000,
        headers: {
          'User-Agent': 'Mozilla/5.0 (compatible; NewsHub/1.0; +https://newshub.com)',
        },
      });

      const $ = cheerio.load(response.data);
      const openGraphData: {
        image?: string;
        title?: string;
        description?: string;
      } = {};

      // Extract Open Graph meta tags
      $('meta[property^="og:"]').each((_, element) => {
        const property = $(element).attr('property');
        const content = $(element).attr('content');
        
        if (property && content) {
          switch (property) {
            case 'og:image':
              openGraphData.image = content;
              break;
            case 'og:title':
              openGraphData.title = content;
              break;
            case 'og:description':
              openGraphData.description = content;
              break;
          }
        }
      });

      // Also check Twitter Card meta tags
      $('meta[name^="twitter:"]').each((_, element) => {
        const name = $(element).attr('name');
        const content = $(element).attr('content');
        
        if (name && content) {
          switch (name) {
            case 'twitter:image':
              if (!openGraphData.image) openGraphData.image = content;
              break;
            case 'twitter:title':
              if (!openGraphData.title) openGraphData.title = content;
              break;
            case 'twitter:description':
              if (!openGraphData.description) openGraphData.description = content;
              break;
          }
        }
      });

      return openGraphData;
    } catch (error) {
      logger.error(`Extract Open Graph data error for ${url}:`, error);
      return {};
    }
  }

  private async determineCategory(title: string, summary: string, sourceCategories: any[]): Promise<any> {
    try {
      const text = (title + ' ' + summary).toLowerCase();
      
      // Simple keyword-based categorization
      const categoryKeywords = {
        'politics': ['politics', 'government', 'election', 'president', 'congress', 'senate', 'democrat', 'republican'],
        'sports': ['sports', 'football', 'basketball', 'baseball', 'soccer', 'tennis', 'olympics', 'game', 'match'],
        'tech': ['technology', 'tech', 'software', 'hardware', 'ai', 'artificial intelligence', 'computer', 'internet'],
        'health': ['health', 'medical', 'doctor', 'hospital', 'medicine', 'disease', 'treatment', 'patient'],
        'world': ['world', 'international', 'global', 'united nations', 'foreign', 'overseas'],
        'business': ['business', 'economy', 'market', 'stock', 'finance', 'money', 'company', 'corporation'],
        'entertainment': ['entertainment', 'movie', 'film', 'music', 'celebrity', 'hollywood', 'tv', 'television'],
        'science': ['science', 'research', 'study', 'discovery', 'scientist', 'experiment', 'innovation'],
      };

      // Find matching category
      for (const [categoryKey, keywords] of Object.entries(categoryKeywords)) {
        if (keywords.some(keyword => text.includes(keyword))) {
          const category = await Category.findOne({ key: categoryKey });
          if (category) {
            return category;
          }
        }
      }

      // Default to first source category or general news
      if (sourceCategories.length > 0) {
        return sourceCategories[0];
      }

      // Fallback to general category
      const generalCategory = await Category.findOne({ key: 'general' }) || await Category.findOne();
      return generalCategory;
    } catch (error) {
      logger.error('Determine category error:', error);
      throw error;
    }
  }

  private extractTags(title: string, summary: string, content: string): string[] {
    try {
      const text = (title + ' ' + summary + ' ' + content).toLowerCase();
      const tags: string[] = [];

      // Simple keyword extraction
      const commonWords = ['the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'is', 'are', 'was', 'were', 'be', 'been', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should'];
      
      const words = text.split(/\s+/).filter(word => word.length > 3 && !commonWords.includes(word));
      
      // Count word frequency
      const wordCount: { [key: string]: number } = {};
      words.forEach(word => {
        const cleanWord = word.replace(/[^\w]/g, '');
        if (cleanWord) {
          wordCount[cleanWord] = (wordCount[cleanWord] || 0) + 1;
        }
      });

      // Get top 5 most frequent words as tags
      const sortedWords = Object.entries(wordCount)
        .sort(([, a], [, b]) => b - a)
        .slice(0, 5)
        .map(([word]) => word);

      return sortedWords;
    } catch (error) {
      logger.error('Extract tags error:', error);
      return [];
    }
  }

  private extractAuthor(content: string): string | null {
    try {
      // Simple author extraction patterns
      const authorPatterns = [
        /by\s+([A-Z][a-z]+\s+[A-Z][a-z]+)/gi,
        /author:\s*([A-Z][a-z]+\s+[A-Z][a-z]+)/gi,
        /written\s+by\s+([A-Z][a-z]+\s+[A-Z][a-z]+)/gi,
      ];

      for (const pattern of authorPatterns) {
        const match = content.match(pattern);
        if (match) {
          return match[0].replace(/by\s+|author:\s*|written\s+by\s+/gi, '').trim();
        }
      }

      return null;
    } catch (error) {
      logger.error('Extract author error:', error);
      return null;
    }
  }

  private cleanContent(html: string): string {
    try {
      const $ = cheerio.load(html);
      
      // Remove unwanted elements
      $('script, style, nav, header, footer, .ads, .advertisement, .comments, .social-share, .related-articles').remove();
      
      // Get text content
      let text = $('body').text();
      
      // Clean up text
      text = text.replace(/\s+/g, ' ').trim();
      text = text.replace(/\n\s*\n/g, '\n\n');
      
      return text;
    } catch (error) {
      logger.error('Clean content error:', error);
      return html;
    }
  }

  private cleanText(text: string): string {
    return text
      .replace(/\s+/g, ' ')
      .replace(/\n\s*\n/g, '\n\n')
      .trim();
  }
}