export { User } from './User';
export { Category } from './Category';
export { Article } from './Article';
export { Source } from './Source';
export { Ticker } from './Ticker';
export { JobLog } from './JobLog';

export interface IModels {
  User: typeof User;
  Category: typeof Category;
  Article: typeof Article;
  Source: typeof Source;
  Ticker: typeof Ticker;
  JobLog: typeof JobLog;
}