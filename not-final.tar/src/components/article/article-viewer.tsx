"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { 
  ArrowLeft, 
  Clock, 
  Eye, 
  Bookmark, 
  Share2, 
  Facebook, 
  Twitter, 
  Linkedin, 
  MessageCircle,
  Heart,
  User,
  Calendar,
  Tag
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";

// Mock article data
const articleData = {
  id: 1,
  title: "Revolutionary AI Technology Transforms Healthcare Industry",
  subtitle: "Breakthrough in artificial intelligence promises to revolutionize medical diagnosis and treatment protocols worldwide",
  author: {
    name: "Dr. Sarah Johnson",
    avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&crop=face",
    bio: "Senior Technology Reporter with 15 years of experience covering AI and healthcare innovations.",
    twitter: "@sarahjtech"
  },
  publishedAt: "2024-01-15T10:30:00Z",
  readTime: "8 min read",
  views: 15420,
  category: "AI",
  tags: ["Artificial Intelligence", "Healthcare", "Technology", "Medical Innovation"],
  image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=1200&h=600&fit=crop",
  content: `
    <p>In a groundbreaking development that promises to reshape the healthcare landscape, researchers at leading medical institutions have unveiled a revolutionary artificial intelligence system capable of diagnosing diseases with unprecedented accuracy.</p>
    
    <p>The AI system, developed through a collaboration between tech giants and medical research centers, has demonstrated remarkable success in early trials, showing diagnostic accuracy rates that surpass human medical professionals in several key areas.</p>
    
    <h3>Breakthrough Capabilities</h3>
    <p>The new AI technology combines advanced machine learning algorithms with vast datasets of medical information, enabling it to identify patterns and correlations that might escape human observation. During clinical trials, the system achieved a 98.2% accuracy rate in detecting early-stage cancers, compared to the 85% average for human radiologists.</p>
    
    <blockquote>"This represents a paradigm shift in how we approach medical diagnosis," said Dr. Michael Chen, lead researcher on the project. "The AI doesn't replace doctors; it augments their capabilities, allowing them to make more informed decisions and catch potential issues earlier than ever before."</blockquote>
    
    <h3>Real-World Applications</h3>
    <p>The technology is already being implemented in several major hospitals across the United States and Europe. Early adopters report significant improvements in diagnostic speed and accuracy, leading to better patient outcomes and reduced healthcare costs.</p>
    
    <p>One particularly promising application is in rural and underserved areas, where access to specialized medical expertise is limited. The AI system can provide expert-level analysis locally, bridging the gap between remote communities and advanced medical care.</p>
    
    <h3>Industry Response</h3>
    <p>Healthcare industry leaders have responded enthusiastically to the development. Major hospital chains are investing heavily in AI infrastructure, while insurance companies are exploring ways to incorporate AI diagnostics into their coverage models.</p>
    
    <p>"We're seeing the beginning of a new era in medicine," said Jennifer Martinez, CEO of HealthTech Innovations. "The integration of AI into healthcare delivery is not just improving outcomes—it's fundamentally changing how we think about medical care."</p>
    
    <h3>Future Implications</h3>
    <p>Looking ahead, researchers are already working on next-generation versions of the technology that could predict diseases before symptoms appear, potentially revolutionizing preventive medicine. The system is also being adapted for use in drug discovery, personalized treatment planning, and medical research.</p>
    
    <p>As the technology continues to evolve, experts predict that AI will become an indispensable tool in healthcare, working alongside human professionals to provide better, faster, and more accessible medical care to people around the world.</p>
  `,
  relatedArticles: [
    {
      id: 2,
      title: "AI in Drug Discovery: Accelerating Medical Breakthroughs",
      summary: "How artificial intelligence is revolutionizing pharmaceutical research and development",
      image: "https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?w=400&h=250&fit=crop",
      category: "AI",
      readTime: "6 min read"
    },
    {
      id: 3,
      title: "The Future of Telemedicine: Trends and Predictions",
      summary: "Exploring the evolving landscape of remote healthcare delivery",
      image: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=400&h=250&fit=crop",
      category: "Health",
      readTime: "5 min read"
    },
    {
      id: 4,
      title: "Ethical Considerations in AI Healthcare Applications",
      summary: "Balancing innovation with patient privacy and ethical concerns",
      image: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=400&h=250&fit=crop",
      category: "Tech",
      readTime: "7 min read"
    }
  ]
};

export default function ArticleViewer() {
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [showShareMenu, setShowShareMenu] = useState(false);

  const handleBookmark = () => {
    setIsBookmarked(!isBookmarked);
  };

  const handleShare = (platform: string) => {
    // Implement share functionality
    console.log(`Sharing to ${platform}`);
    setShowShareMenu(false);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-32 pb-16">
        <div className="container mx-auto px-4 max-w-4xl">
          {/* Back Button */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Button variant="ghost" className="mb-6">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to News
            </Button>
          </motion.div>

          {/* Article Header */}
          <motion.article
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="mb-6">
              <Badge variant="secondary" className="mb-4">
                {articleData.category}
              </Badge>
              <h1 className="text-3xl md:text-5xl font-bold mb-4 leading-tight">
                {articleData.title}
              </h1>
              <p className="text-xl text-muted-foreground mb-6">
                {articleData.subtitle}
              </p>
              
              {/* Article Meta */}
              <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground mb-6">
                <div className="flex items-center gap-1">
                  <Calendar className="h-4 w-4" />
                  {formatDate(articleData.publishedAt)}
                </div>
                <div className="flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  {articleData.readTime}
                </div>
                <div className="flex items-center gap-1">
                  <Eye className="h-4 w-4" />
                  {articleData.views.toLocaleString()} views
                </div>
              </div>

              {/* Tags */}
              <div className="flex flex-wrap gap-2 mb-6">
                {articleData.tags.map((tag) => (
                  <div key={tag} className="flex items-center gap-1 bg-muted px-3 py-1 rounded-full text-sm">
                    <Tag className="h-3 w-3" />
                    {tag}
                  </div>
                ))}
              </div>
            </div>

            {/* Featured Image */}
            <div className="relative h-64 md:h-96 rounded-xl overflow-hidden mb-8">
              <img
                src={articleData.image}
                alt={articleData.title}
                className="w-full h-full object-cover"
              />
            </div>

            {/* Author Info */}
            <Card className="mb-8">
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <Avatar className="h-16 w-16">
                    <AvatarImage src={articleData.author.avatar} alt={articleData.author.name} />
                    <AvatarFallback>
                      <User className="h-8 w-8" />
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg mb-1">{articleData.author.name}</h3>
                    <p className="text-muted-foreground text-sm mb-2">{articleData.author.bio}</p>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <MessageCircle className="h-4 w-4" />
                      <span>@{articleData.author.twitter}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Article Content */}
            <div className="prose prose-lg max-w-none mb-8">
              <div 
                className="[&_h3]:text-2xl [&_h3]:font-bold [&_h3]:mb-4 [&_h3]:mt-8 [&_p]:text-base [&_p]:leading-relaxed [&_p]:mb-4 [&_blockquote]:border-l-4 [&_blockquote]:border-primary [&_blockquote]:pl-4 [&_blockquote]:italic [&_blockquote]:my-6 [&_blockquote]:text-muted-foreground"
                dangerouslySetInnerHTML={{ __html: articleData.content }}
              />
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-between py-6 border-t border-border">
              <div className="flex items-center gap-2">
                <Button
                  variant={isBookmarked ? "default" : "outline"}
                  size="sm"
                  onClick={handleBookmark}
                  className="flex items-center gap-2"
                >
                  <Bookmark className={`h-4 w-4 ${isBookmarked ? "fill-current" : ""}`} />
                  {isBookmarked ? "Saved" : "Save"}
                </Button>
                
                <div className="relative">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowShareMenu(!showShareMenu)}
                    className="flex items-center gap-2"
                  >
                    <Share2 className="h-4 w-4" />
                    Share
                  </Button>
                  
                  {showShareMenu && (
                    <div className="absolute top-full left-0 mt-2 bg-background border border-border rounded-lg shadow-lg p-2 z-10">
                      <div className="flex gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleShare("facebook")}
                          className="text-blue-600 hover:text-blue-700"
                        >
                          <Facebook className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleShare("twitter")}
                          className="text-sky-600 hover:text-sky-700"
                        >
                          <Twitter className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleShare("linkedin")}
                          className="text-blue-700 hover:text-blue-800"
                        >
                          <Linkedin className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="sm">
                  <Heart className="h-4 w-4 mr-1" />
                  2.3K
                </Button>
                <Button variant="ghost" size="sm">
                  <MessageCircle className="h-4 w-4 mr-1" />
                  156
                </Button>
              </div>
            </div>

            <Separator className="my-8" />

            {/* Related Articles */}
            <section>
              <h2 className="text-2xl font-bold mb-6">Related Articles</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {articleData.relatedArticles.map((article) => (
                  <Card key={article.id} className="group hover:shadow-lg transition-shadow">
                    <div className="aspect-video bg-muted rounded-t-lg overflow-hidden">
                      <img
                        src={article.image}
                        alt={article.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <CardContent className="p-4">
                      <Badge variant="secondary" className="mb-2">
                        {article.category}
                      </Badge>
                      <h3 className="font-semibold mb-2 line-clamp-2 group-hover:text-primary transition-colors">
                        {article.title}
                      </h3>
                      <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
                        {article.summary}
                      </p>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-muted-foreground">
                          {article.readTime}
                        </span>
                        <Button variant="ghost" size="sm">
                          Read More
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </section>
          </motion.article>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}