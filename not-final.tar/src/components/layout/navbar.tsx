"use client";

import { useState } from "react";
import { Search, Menu, X, Sun, Moon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useTheme } from "next-themes";
import { cn } from "@/lib/utils";

const categories = [
  { name: "Breaking News", href: "/breaking" },
  { name: "Politics", href: "/politics" },
  { name: "World", href: "/world" },
  { name: "Sports", href: "/sports" },
  { name: "Tech", href: "/tech" },
  { name: "Health", href: "/health" },
  { name: "AI", href: "/ai" },
  { name: "Cyber", href: "/cyber" },
  { name: "Movies", href: "/movies" },
  { name: "Stocks", href: "/stocks" },
  { name: "Hindi", href: "/hindi" },
  { name: "Telugu", href: "/telugu" },
];

export function Navbar() {
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const { theme, setTheme } = useTheme();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Searching for:", searchQuery);
    // Implement search functionality
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-md border-b border-border">
      <div className="container mx-auto px-4">
        {/* Breaking News Ticker */}
        <div className="h-8 flex items-center bg-red-600 text-white overflow-hidden">
          <div className="bg-red-700 px-3 py-1 font-semibold text-sm whitespace-nowrap">
            BREAKING
          </div>
          <div className="flex-1 overflow-hidden">
            <div className="animate-marquee whitespace-nowrap px-4 text-sm">
              Major earthquake strikes Pacific region • Tech giant announces revolutionary AI breakthrough • 
              Global climate summit reaches historic agreement • Stock markets hit all-time high • 
              Sports championship finals set new viewership records
            </div>
          </div>
        </div>

        {/* Main Navbar */}
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center">
            <a href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">N</span>
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                NewsHub
              </span>
            </a>
          </div>

          {/* Desktop Categories */}
          <div className="hidden md:flex items-center space-x-1">
            {categories.slice(0, 6).map((category) => (
              <Button
                key={category.name}
                variant="ghost"
                className="h-9 px-3 text-sm font-medium hover:bg-accent hover:text-accent-foreground"
                asChild
              >
                <a href={category.href}>{category.name}</a>
              </Button>
            ))}
          </div>

          {/* Search and Theme Toggle */}
          <div className="flex items-center space-x-2">
            <form onSubmit={handleSearch} className="hidden md:flex items-center">
              <div className="relative">
                <Input
                  type="search"
                  placeholder="Search news..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onFocus={() => setIsSearchFocused(true)}
                  onBlur={() => setIsSearchFocused(false)}
                  className={cn(
                    "w-64 transition-all duration-300",
                    isSearchFocused && "w-80"
                  )}
                />
                <Button
                  type="submit"
                  size="sm"
                  variant="ghost"
                  className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                >
                  <Search className="h-4 w-4" />
                </Button>
              </div>
            </form>

            <Button
              variant="ghost"
              size="sm"
              onClick={() => setTheme(theme === "light" ? "dark" : "light")}
              className="h-9 w-9 p-0"
            >
              <Sun className="h-4 w-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
              <Moon className="absolute h-4 w-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
              <span className="sr-only">Toggle theme</span>
            </Button>

            {/* Mobile Menu */}
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="sm" className="md:hidden h-9 w-9 p-0">
                  <Menu className="h-4 w-4" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-80">
                <div className="flex flex-col space-y-6 mt-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                        <span className="text-white font-bold text-lg">N</span>
                      </div>
                      <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                        NewsHub
                      </span>
                    </div>
                  </div>
                  
                  {/* Mobile Search */}
                  <form onSubmit={handleSearch} className="flex items-center">
                    <div className="relative flex-1">
                      <Input
                        type="search"
                        placeholder="Search news..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pr-10"
                      />
                      <Button
                        type="submit"
                        size="sm"
                        variant="ghost"
                        className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                      >
                        <Search className="h-4 w-4" />
                      </Button>
                    </div>
                  </form>

                  {/* Mobile Categories */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Categories</h3>
                    <div className="grid grid-cols-1 gap-2">
                      {categories.map((category) => (
                        <Button
                          key={category.name}
                          variant="ghost"
                          className="justify-start h-10 px-4 text-sm font-medium hover:bg-accent hover:text-accent-foreground rounded-lg"
                          asChild
                        >
                          <a href={category.href}>{category.name}</a>
                        </Button>
                      ))}
                    </div>
                  </div>

                  {/* Theme Toggle in Mobile Menu */}
                  <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
                    <span className="text-sm font-medium">Theme</span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setTheme(theme === "light" ? "dark" : "light")}
                      className="flex items-center gap-2"
                    >
                      <Sun className="h-4 w-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
                      <Moon className="absolute h-4 w-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
                      <span className="sr-only">Toggle theme</span>
                    </Button>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  );
}