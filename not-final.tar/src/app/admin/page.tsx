'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { 
  Settings, 
  FileText, 
  Users, 
  TrendingUp, 
  Clock, 
  CheckCircle, 
  XCircle, 
  AlertCircle,
  Plus,
  Edit,
  Trash2,
  Eye,
  RefreshCw
} from 'lucide-react';

interface Article {
  _id: string;
  title: string;
  summary: string;
  status: 'draft' | 'published' | 'rejected' | 'needs_review';
  category: string;
  author: string;
  publishedAt?: string;
  createdAt: string;
  aiInfo: {
    rewritten: boolean;
    confidence: number;
    plagiarismScore: number;
  };
  factCheck?: {
    isReliable: boolean;
    confidence: number;
  };
  viewCount: number;
}

interface Source {
  _id: string;
  name: string;
  url: string;
  rssUrls: string[];
  active: boolean;
  categories: string[];
  lastScraped?: string;
}

interface Analytics {
  totalArticles: number;
  publishedArticles: number;
  draftArticles: number;
  rejectedArticles: number;
  totalViews: number;
  avgPlagiarismScore: number;
  sourcesCount: number;
  activeSources: number;
}

export default function AdminDashboard() {
  const [articles, setArticles] = useState<Article[]>([]);
  const [sources, setSources] = useState<Source[]>([]);
  const [analytics, setAnalytics] = useState<Analytics | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);
  const [showArticleModal, setShowArticleModal] = useState(false);
  const [showSourceModal, setShowSourceModal] = useState(false);
  const [editingSource, setEditingSource] = useState<Source | null>(null);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      
      // Fetch articles (in real app, this would be from your API)
      const articlesResponse = await fetch('/api/admin/articles');
      if (articlesResponse.ok) {
        const articlesData = await articlesResponse.json();
        setArticles(articlesData);
      }

      // Fetch sources
      const sourcesResponse = await fetch('/api/admin/sources');
      if (sourcesResponse.ok) {
        const sourcesData = await sourcesResponse.json();
        setSources(sourcesData);
      }

      // Fetch analytics
      const analyticsResponse = await fetch('/api/admin/analytics');
      if (analyticsResponse.ok) {
        const analyticsData = await analyticsResponse.json();
        setAnalytics(analyticsData);
      }
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleArticleAction = async (articleId: string, action: 'approve' | 'reject' | 'publish') => {
    try {
      const response = await fetch(`/api/admin/articles/${articleId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ action }),
      });

      if (response.ok) {
        fetchDashboardData(); // Refresh data
      }
    } catch (error) {
      console.error('Error updating article:', error);
    }
  };

  const handleSourceToggle = async (sourceId: string, active: boolean) => {
    try {
      const response = await fetch(`/api/admin/sources/${sourceId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ active }),
      });

      if (response.ok) {
        fetchDashboardData(); // Refresh data
      }
    } catch (error) {
      console.error('Error updating source:', error);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'published':
        return <Badge className="bg-green-500"><CheckCircle className="w-3 h-3 mr-1" /> Published</Badge>;
      case 'draft':
        return <Badge className="bg-blue-500"><Clock className="w-3 h-3 mr-1" /> Draft</Badge>;
      case 'rejected':
        return <Badge className="bg-red-500"><XCircle className="w-3 h-3 mr-1" /> Rejected</Badge>;
      case 'needs_review':
        return <Badge className="bg-yellow-500"><AlertCircle className="w-3 h-3 mr-1" /> Needs Review</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <RefreshCw className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Admin Dashboard</h1>
          <p className="text-muted-foreground">Manage your news platform</p>
        </div>
        <Button onClick={fetchDashboardData} variant="outline">
          <RefreshCw className="w-4 h-4 mr-2" />
          Refresh
        </Button>
      </div>

      {/* Analytics Cards */}
      {analytics && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Articles</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{analytics.totalArticles}</div>
              <p className="text-xs text-muted-foreground">
                {analytics.publishedArticles} published
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Sources</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{analytics.activeSources}</div>
              <p className="text-xs text-muted-foreground">
                of {analytics.sourcesCount} total sources
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Views</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{analytics.totalViews.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                across all articles
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Avg. Quality</CardTitle>
              <Settings className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{Math.round(100 - analytics.avgPlagiarismScore)}%</div>
              <p className="text-xs text-muted-foreground">
                content quality score
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      <Tabs defaultValue="articles" className="space-y-4">
        <TabsList>
          <TabsTrigger value="articles">Articles</TabsTrigger>
          <TabsTrigger value="sources">Sources</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="articles" className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-semibold">Article Management</h2>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Article Review Queue</CardTitle>
              <CardDescription>
                Review and manage AI-processed articles before publication
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Title</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>AI Confidence</TableHead>
                    <TableHead>Plagiarism</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {articles.slice(0, 10).map((article) => (
                    <TableRow key={article._id}>
                      <TableCell className="font-medium max-w-xs">
                        <div className="truncate" title={article.title}>
                          {article.title}
                        </div>
                      </TableCell>
                      <TableCell>{getStatusBadge(article.status)}</TableCell>
                      <TableCell>{article.category}</TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <div className="w-12 bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-blue-600 h-2 rounded-full" 
                              style={{ width: `${article.aiInfo.confidence}%` }}
                            ></div>
                          </div>
                          <span className="text-sm">{article.aiInfo.confidence}%</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <div className="w-12 bg-gray-200 rounded-full h-2">
                            <div 
                              className={`h-2 rounded-full ${
                                article.aiInfo.plagiarismScore < 20 ? 'bg-green-600' : 
                                article.aiInfo.plagiarismScore < 50 ? 'bg-yellow-600' : 'bg-red-600'
                              }`}
                              style={{ width: `${Math.min(article.aiInfo.plagiarismScore, 100)}%` }}
                            ></div>
                          </div>
                          <span className="text-sm">{article.aiInfo.plagiarismScore}%</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setSelectedArticle(article);
                              setShowArticleModal(true);
                            }}
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                          {article.status === 'needs_review' && (
                            <>
                              <Button
                                size="sm"
                                variant="default"
                                onClick={() => handleArticleAction(article._id, 'approve')}
                              >
                                <CheckCircle className="w-4 h-4" />
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => handleArticleAction(article._id, 'reject')}
                              >
                                <XCircle className="w-4 h-4" />
                              </Button>
                            </>
                          )}
                          {article.status === 'draft' && (
                            <Button
                              size="sm"
                              variant="default"
                              onClick={() => handleArticleAction(article._id, 'publish')}
                            >
                              Publish
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sources" className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-semibold">Source Management</h2>
            <Button onClick={() => setShowSourceModal(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Add Source
            </Button>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>News Sources</CardTitle>
              <CardDescription>
                Manage RSS feeds and content sources
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>URL</TableHead>
                    <TableHead>Categories</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Last Scraped</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sources.map((source) => (
                    <TableRow key={source._id}>
                      <TableCell className="font-medium">{source.name}</TableCell>
                      <TableCell className="max-w-xs">
                        <div className="truncate" title={source.url}>
                          {source.url}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {source.categories.map((cat, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {cat}
                            </Badge>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Switch
                          checked={source.active}
                          onCheckedChange={(checked) => handleSourceToggle(source._id, checked)}
                        />
                      </TableCell>
                      <TableCell>
                        {source.lastScraped 
                          ? new Date(source.lastScraped).toLocaleDateString()
                          : 'Never'
                        }
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setEditingSource(source);
                              setShowSourceModal(true);
                            }}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button size="sm" variant="outline">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <h2 className="text-2xl font-semibold">Analytics Dashboard</h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Article Status Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {analytics && (
                    <>
                      <div className="flex items-center justify-between">
                        <span>Published</span>
                        <span className="font-semibold">{analytics.publishedArticles}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Draft</span>
                        <span className="font-semibold">{analytics.draftArticles}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Rejected</span>
                        <span className="font-semibold">{analytics.rejectedArticles}</span>
                      </div>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Content Quality Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {analytics && (
                    <>
                      <div className="flex items-center justify-between">
                        <span>Average Plagiarism Score</span>
                        <span className="font-semibold">{analytics.avgPlagiarismScore.toFixed(1)}%</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Content Quality Score</span>
                        <span className="font-semibold">{Math.round(100 - analytics.avgPlagiarismScore)}%</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Total Views</span>
                        <span className="font-semibold">{analytics.totalViews.toLocaleString()}</span>
                      </div>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          <h2 className="text-2xl font-semibold">Settings</h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Content Processing</CardTitle>
                <CardDescription>
                  Configure AI content processing settings
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Auto-publish approved articles</Label>
                    <p className="text-sm text-muted-foreground">
                      Automatically publish articles that pass quality checks
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Enable fact-checking</Label>
                    <p className="text-sm text-muted-foreground">
                      Run automated fact-checking on all articles
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>

                <div className="space-y-2">
                  <Label>Plagiarism threshold</Label>
                  <Select defaultValue="20">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="10">10% - Strict</SelectItem>
                      <SelectItem value="20">20% - Moderate</SelectItem>
                      <SelectItem value="30">30% - Lenient</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Default tone</Label>
                  <Select defaultValue="neutral">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="formal">Formal</SelectItem>
                      <SelectItem value="neutral">Neutral</SelectItem>
                      <SelectItem value="exciting">Exciting</SelectItem>
                      <SelectItem value="breaking">Breaking News</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Scraping Configuration</CardTitle>
                <CardDescription>
                  Configure content scraping settings
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Scraping interval</Label>
                  <Select defaultValue="5">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1 minute</SelectItem>
                      <SelectItem value="5">5 minutes</SelectItem>
                      <SelectItem value="15">15 minutes</SelectItem>
                      <SelectItem value="30">30 minutes</SelectItem>
                      <SelectItem value="60">1 hour</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Articles per source</Label>
                  <Input type="number" defaultValue="10" min="1" max="50" />
                </div>

                <div className="space-y-2">
                  <Label>User agent</Label>
                  <Input defaultValue="Mozilla/5.0 (compatible; NewsHub/1.0; +https://newshub.com)" />
                </div>

                <div className="space-y-2">
                  <Label>Request timeout (seconds)</Label>
                  <Input type="number" defaultValue="10" min="5" max="60" />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}