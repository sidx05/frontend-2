"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { ArrowRight, Clock, TrendingUp, Bookmark, Share2, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";
import NewsletterSubscribe from "@/components/newsletter/newsletter-subscribe";
import ArticleSummary from "@/components/article/article-summary";

// Mock data for demonstration
const featuredArticles = [
  {
    id: 1,
    title: "Revolutionary AI Technology Transforms Healthcare Industry",
    summary: "Breakthrough in artificial intelligence promises to revolutionize medical diagnosis and treatment protocols worldwide.",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=400&fit=crop",
    category: "AI",
    time: "2 hours ago",
    readTime: "5 min read",
  },
  {
    id: 2,
    title: "Global Climate Summit Reaches Historic Agreement",
    summary: "World leaders unite on unprecedented climate action plan with binding commitments for carbon neutrality.",
    image: "https://images.unsplash.com/photo-1464822759844-d150baec0494?w=800&h=400&fit=crop",
    category: "World",
    time: "4 hours ago",
    readTime: "7 min read",
  },
  {
    id: 3,
    title: "Tech Giants Unveil Next-Generation Quantum Computing",
    summary: "Major technology companies announce breakthrough developments in quantum processing power and applications.",
    image: "https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&h=400&fit=crop",
    category: "Tech",
    time: "6 hours ago",
    readTime: "6 min read",
  },
];

const latestArticles = [
  {
    id: 4,
    title: "Stock Markets Reach All-Time High Amid Economic Recovery",
    summary: "Global markets surge as economic indicators show strong recovery signs across major sectors.",
    image: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=400&h=250&fit=crop",
    category: "Stocks",
    time: "1 hour ago",
    readTime: "4 min read",
    views: 15420,
  },
  {
    id: 5,
    title: "Championship Finals Break Viewership Records",
    summary: "Sports championship attracts unprecedented global audience with thrilling finale.",
    image: "https://images.unsplash.com/photo-1540747933386-5627b101f40c?w=400&h=250&fit=crop",
    category: "Sports",
    time: "3 hours ago",
    readTime: "3 min read",
    views: 8934,
  },
  {
    id: 6,
    title: "New Cybersecurity Threats Target Financial Institutions",
    summary: "Security experts warn of sophisticated cyber attacks targeting banking systems worldwide.",
    image: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=400&h=250&fit=crop",
    category: "Cyber",
    time: "5 hours ago",
    readTime: "5 min read",
    views: 6721,
  },
  {
    id: 7,
    title: "Breakthrough in Cancer Research Offers New Hope",
    summary: "Medical researchers announce promising results from new treatment approach.",
    image: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=400&h=250&fit=crop",
    category: "Health",
    time: "7 hours ago",
    readTime: "6 min read",
    views: 12890,
  },
];

const trendingTopics = [
  { name: "AI Revolution", count: 15420, trend: "up" },
  { name: "Climate Action", count: 12350, trend: "up" },
  { name: "Space Exploration", count: 9876, trend: "up" },
  { name: "Cryptocurrency", count: 8765, trend: "down" },
  { name: "Electric Vehicles", count: 7654, trend: "up" },
  { name: "Metaverse", count: 6543, trend: "stable" },
];

const categoryArticles = [
  {
    category: "Politics",
    articles: [
      {
        id: 8,
        title: "Historic Legislation Passes Senate Vote",
        summary: "Landmark bill approved with bipartisan support after months of negotiation.",
        time: "2 hours ago",
      },
      {
        id: 9,
        title: "International Diplomatic Mission Shows Progress",
        summary: "Peace talks yield positive results in ongoing international conflict.",
        time: "5 hours ago",
      },
    ],
  },
  {
    category: "Movies",
    articles: [
      {
        id: 10,
        title: "Blockbuster Film Breaks Box Office Records",
        summary: "New movie release surpasses all expectations in opening weekend.",
        time: "3 hours ago",
      },
      {
        id: 11,
        title: "Streaming Wars Intensify with New Platform Launch",
        summary: "Major entertainment company enters competitive streaming market.",
        time: "6 hours ago",
      },
    ],
  },
];

export default function Home() {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % featuredArticles.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Main Content */}
      <main className="pt-32 pb-16">
        <div className="container mx-auto px-4">
          {/* Featured News Carousel */}
          <section className="mb-12">
            <div className="relative h-96 md:h-[500px] rounded-2xl overflow-hidden">
              {featuredArticles.map((article, index) => (
                <motion.div
                  key={article.id}
                  className="absolute inset-0"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: index === currentSlide ? 1 : 0 }}
                  transition={{ duration: 0.5 }}
                >
                  <div
                    className="relative h-full bg-cover bg-center"
                    style={{ backgroundImage: `url(${article.image})` }}
                  >
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
                    <div className="absolute bottom-0 left-0 right-0 p-8 text-white">
                      <Badge variant="secondary" className="mb-4">
                        {article.category}
                      </Badge>
                      <h1 className="text-3xl md:text-5xl font-bold mb-4">
                        {article.title}
                      </h1>
                      <p className="text-lg md:text-xl mb-4 max-w-3xl">
                        {article.summary}
                      </p>
                      <div className="flex items-center gap-4 text-sm">
                        <div className="flex items-center gap-1">
                          <Clock className="h-4 w-4" />
                          {article.time}
                        </div>
                        <div className="flex items-center gap-1">
                          <Eye className="h-4 w-4" />
                          {article.readTime}
                        </div>
                        <Button variant="secondary" size="sm">
                          Read More <ArrowRight className="h-4 w-4 ml-1" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
              
              {/* Carousel Indicators */}
              <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-2">
                {featuredArticles.map((_, index) => (
                  <button
                    key={index}
                    className={`w-2 h-2 rounded-full transition-colors ${
                      index === currentSlide ? "bg-white" : "bg-white/50"
                    }`}
                    onClick={() => setCurrentSlide(index)}
                  />
                ))}
              </div>
            </div>
          </section>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Latest News Grid */}
            <div className="lg:col-span-2">
              <section className="mb-8">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold">Latest News</h2>
                  <Button variant="outline" size="sm">
                    View All <ArrowRight className="h-4 w-4 ml-1" />
                  </Button>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {latestArticles.map((article) => (
                    <Card key={article.id} className="group hover:shadow-lg transition-shadow flex flex-col h-full">
                      <div className="aspect-video bg-muted rounded-t-lg overflow-hidden flex-shrink-0">
                        <img
                          src={article.image}
                          alt={article.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      </div>
                      <CardContent className="p-6 flex flex-col flex-1">
                        <div className="flex items-center gap-2 mb-3">
                          <Badge variant="secondary" className="text-xs">{article.category}</Badge>
                          <span className="text-sm text-muted-foreground">
                            {article.time}
                          </span>
                        </div>
                        <h3 className="font-semibold mb-3 line-clamp-2 text-lg leading-tight flex-1">
                          {article.title}
                        </h3>
                        <p className="text-sm text-muted-foreground mb-4 line-clamp-2 flex-1">
                          {article.summary}
                        </p>
                        <div className="flex items-center justify-between mt-auto pt-3 border-t border-border">
                          <div className="flex items-center gap-1 text-xs text-muted-foreground">
                            <Eye className="h-3 w-3" />
                            {article.views.toLocaleString()} views
                          </div>
                          <div className="flex items-center gap-1">
                            <Button variant="ghost" size="sm" className="h-8 w-8 p-0 hover:bg-accent">
                              <Bookmark className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm" className="h-8 w-8 p-0 hover:bg-accent">
                              <Share2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </section>

              {/* Category Sections */}
              <section>
                <h2 className="text-2xl font-bold mb-6">More News</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {categoryArticles.map((section) => (
                    <Card key={section.category} className="h-full">
                      <CardHeader className="pb-4">
                        <CardTitle className="flex items-center gap-2 text-lg">
                          {section.category}
                          <ArrowRight className="h-4 w-4" />
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-6">
                        {section.articles.map((article) => (
                          <div key={article.id} className="group pb-4 last:pb-0 border-b border-border last:border-0">
                            <h4 className="font-medium mb-2 group-hover:text-primary transition-colors line-clamp-2 text-base">
                              {article.title}
                            </h4>
                            <p className="text-sm text-muted-foreground line-clamp-3 mb-3">
                              {article.summary}
                            </p>
                            <span className="text-xs text-muted-foreground">
                              {article.time}
                            </span>
                          </div>
                        ))}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </section>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Trending Topics */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    Trending Topics
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {trendingTopics.map((topic, index) => (
                    <div key={topic.name} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <span className="text-lg font-bold text-muted-foreground">
                          {index + 1}
                        </span>
                        <span className="font-medium">{topic.name}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-muted-foreground">
                          {topic.count.toLocaleString()}
                        </span>
                        <div
                          className={`w-2 h-2 rounded-full ${
                            topic.trend === "up"
                              ? "bg-green-500"
                              : topic.trend === "down"
                              ? "bg-red-500"
                              : "bg-gray-500"
                          }`}
                        />
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Newsletter Subscription */}
              <NewsletterSubscribe />
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}