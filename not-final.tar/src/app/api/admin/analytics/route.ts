import { NextRequest, NextResponse } from 'next/server';

// Mock analytics data - in a real app, this would be calculated from your database
const mockAnalytics = {
  totalArticles: 1250,
  publishedArticles: 890,
  draftArticles: 280,
  rejectedArticles: 80,
  totalViews: 245678,
  avgPlagiarismScore: 15.2,
  sourcesCount: 25,
  activeSources: 18,
  articlesByCategory: {
    technology: 350,
    business: 280,
    world: 220,
    health: 150,
    sports: 120,
    entertainment: 80,
    science: 50
  },
  articlesByStatus: {
    published: 890,
    draft: 280,
    rejected: 80
  },
  viewsByDay: [
    { date: '2024-01-09', views: 12000 },
    { date: '2024-01-10', views: 15000 },
    { date: '2024-01-11', views: 18000 },
    { date: '2024-01-12', views: 22000 },
    { date: '2024-01-13', views: 25000 },
    { date: '2024-01-14', views: 28000 },
    { date: '2024-01-15', views: 32000 }
  ],
  topSources: [
    { name: 'TechCrunch', articles: 156, views: 45000 },
    { name: 'BBC News', articles: 142, views: 38000 },
    { name: 'Reuters', articles: 128, views: 35000 },
    { name: 'CNN', articles: 98, views: 28000 },
    { name: 'The Verge', articles: 87, views: 22000 }
  ],
  plagiarismDistribution: {
    '0-10%': 450,
    '11-20%': 380,
    '21-30%': 220,
    '31-50%': 150,
    '50%+': 50
  }
};

export async function GET(request: NextRequest) {
  try {
    // In a real app, you would:
    // 1. Verify authentication/authorization
    // 2. Connect to your database
    // 3. Calculate analytics from actual data
    
    const { searchParams } = new URL(request.url);
    const period = searchParams.get('period') || '7d'; // 7d, 30d, 90d, 1y
    
    // In a real implementation, you would filter data based on the period
    // For now, we'll return the same mock data regardless of period

    return NextResponse.json(mockAnalytics);
  } catch (error) {
    console.error('Error fetching analytics:', error);
    return NextResponse.json(
      { error: 'Failed to fetch analytics' },
      { status: 500 }
    );
  }
}