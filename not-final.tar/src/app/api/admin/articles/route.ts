import { NextRequest, NextResponse } from 'next/server';

// Mock data for demonstration - in a real app, this would come from your database
const mockArticles = [
  {
    _id: '1',
    title: 'Breaking: Major Technology Company Announces Revolutionary AI Breakthrough',
    summary: 'A leading tech company has unveiled a groundbreaking AI technology that promises to transform the industry...',
    status: 'needs_review',
    category: 'technology',
    author: 'NewsHub AI',
    publishedAt: undefined,
    createdAt: '2024-01-15T10:30:00Z',
    aiInfo: {
      rewritten: true,
      confidence: 85,
      plagiarismScore: 12
    },
    factCheck: {
      isReliable: true,
      confidence: 90
    },
    viewCount: 1250
  },
  {
    _id: '2',
    title: 'Global Markets React to Economic Policy Changes',
    summary: 'Financial markets worldwide showed mixed reactions to the latest economic policy announcements...',
    status: 'draft',
    category: 'business',
    author: 'NewsHub AI',
    publishedAt: undefined,
    createdAt: '2024-01-15T09:15:00Z',
    aiInfo: {
      rewritten: true,
      confidence: 92,
      plagiarismScore: 8
    },
    viewCount: 890
  },
  {
    _id: '3',
    title: 'New Study Reveals Surprising Health Benefits of Mediterranean Diet',
    summary: 'Research confirms significant health improvements from traditional Mediterranean eating patterns...',
    status: 'published',
    category: 'health',
    author: 'NewsHub AI',
    publishedAt: '2024-01-14T14:20:00Z',
    createdAt: '2024-01-14T12:00:00Z',
    aiInfo: {
      rewritten: true,
      confidence: 88,
      plagiarismScore: 15
    },
    factCheck: {
      isReliable: true,
      confidence: 95
    },
    viewCount: 2450
  },
  {
    _id: '4',
    title: 'Sports Championship Finals Break Viewership Records',
    summary: 'The championship finals attracted unprecedented viewership numbers across multiple platforms...',
    status: 'rejected',
    category: 'sports',
    author: 'NewsHub AI',
    publishedAt: undefined,
    createdAt: '2024-01-13T16:45:00Z',
    aiInfo: {
      rewritten: true,
      confidence: 45,
      plagiarismScore: 65
    },
    viewCount: 0
  },
  {
    _id: '5',
    title: 'Climate Summit Reaches Historic Agreement on Carbon Emissions',
    summary: 'World leaders have committed to ambitious new targets for reducing carbon emissions by 2030...',
    status: 'published',
    category: 'world',
    author: 'NewsHub AI',
    publishedAt: '2024-01-13T11:30:00Z',
    createdAt: '2024-01-13T09:00:00Z',
    aiInfo: {
      rewritten: true,
      confidence: 94,
      plagiarismScore: 5
    },
    factCheck: {
      isReliable: true,
      confidence: 98
    },
    viewCount: 3200
  }
];

export async function GET(request: NextRequest) {
  try {
    // In a real app, you would:
    // 1. Verify authentication/authorization
    // 2. Connect to your database
    // 3. Fetch articles with proper filtering and pagination
    
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const category = searchParams.get('category');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');

    let filteredArticles = mockArticles;

    // Apply filters
    if (status) {
      filteredArticles = filteredArticles.filter(article => article.status === status);
    }
    if (category) {
      filteredArticles = filteredArticles.filter(article => article.category === category);
    }

    // Apply pagination
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedArticles = filteredArticles.slice(startIndex, endIndex);

    return NextResponse.json({
      articles: paginatedArticles,
      pagination: {
        currentPage: page,
        totalPages: Math.ceil(filteredArticles.length / limit),
        totalArticles: filteredArticles.length,
        hasNext: endIndex < filteredArticles.length,
        hasPrev: page > 1
      }
    });
  } catch (error) {
    console.error('Error fetching articles:', error);
    return NextResponse.json(
      { error: 'Failed to fetch articles' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    // In a real app, you would:
    // 1. Verify authentication/authorization
    // 2. Validate input data
    // 3. Create new article in database
    
    const body = await request.json();
    
    // Validate required fields
    const requiredFields = ['title', 'content', 'category'];
    for (const field of requiredFields) {
      if (!body[field]) {
        return NextResponse.json(
          { error: `${field} is required` },
          { status: 400 }
        );
      }
    }

    // Create new article (mock)
    const newArticle = {
      _id: Date.now().toString(),
      title: body.title,
      summary: body.summary || '',
      content: body.content,
      status: 'draft',
      category: body.category,
      author: body.author || 'Admin',
      publishedAt: undefined,
      createdAt: new Date().toISOString(),
      aiInfo: {
        rewritten: false,
        confidence: 0,
        plagiarismScore: 0
      },
      viewCount: 0,
      ...body
    };

    return NextResponse.json(newArticle, { status: 201 });
  } catch (error) {
    console.error('Error creating article:', error);
    return NextResponse.json(
      { error: 'Failed to create article' },
      { status: 500 }
    );
  }
}