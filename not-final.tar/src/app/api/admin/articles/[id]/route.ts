import { NextRequest, NextResponse } from 'next/server';

// Mock articles data - in a real app, this would come from your database
const mockArticles = [
  {
    _id: '1',
    title: 'Breaking: Major Technology Company Announces Revolutionary AI Breakthrough',
    summary: 'A leading tech company has unveiled a groundbreaking AI technology that promises to transform the industry...',
    content: `In a stunning announcement that has sent shockwaves through the technology sector, TechCorp unveiled its latest artificial intelligence breakthrough that promises to revolutionize how we interact with machines. The new system, dubbed "NeuralSync," demonstrates unprecedented capabilities in natural language understanding and problem-solving.

Speaking at a press conference at the company's headquarters, CEO Sarah Johnson described the development as "the most significant advancement in AI since the advent of machine learning." The technology has been in development for over five years and represents a quantum leap in cognitive computing.

What sets NeuralSync apart from existing AI systems is its ability to understand context and nuance in ways that closely mimic human cognition. Early tests show the system can comprehend complex instructions, learn from minimal examples, and even demonstrate creative problem-solving abilities.

Industry analysts are already predicting widespread applications across various sectors, from healthcare and education to manufacturing and entertainment. "This isn't just an incremental improvement," said Dr. Michael Chen, AI researcher at MIT. "This represents a fundamental shift in what's possible with artificial intelligence."

The company plans to roll out the technology gradually, starting with partnerships in the healthcare sector before expanding to other industries. Regulatory approval and ethical considerations are being carefully addressed as part of the deployment strategy.`,
    status: 'needs_review',
    category: 'technology',
    author: 'NewsHub AI',
    publishedAt: undefined,
    createdAt: '2024-01-15T10:30:00Z',
    aiInfo: {
      rewritten: true,
      confidence: 85,
      plagiarismScore: 12
    },
    factCheck: {
      isReliable: true,
      confidence: 90
    },
    viewCount: 1250,
    images: [
      {
        url: 'https://example.com/ai-tech-image.jpg',
        alt: 'AI technology demonstration',
        caption: 'NeuralSync AI system in action',
        width: 1200,
        height: 800,
        generated: false
      }
    ],
    tags: ['AI', 'technology', 'innovation', 'TechCorp', 'NeuralSync'],
    seo: {
      metaDescription: 'TechCorp announces revolutionary AI breakthrough with NeuralSync technology, promising to transform human-machine interaction.',
      keywords: ['AI', 'artificial intelligence', 'technology', 'TechCorp', 'NeuralSync', 'innovation']
    }
  }
];

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params;
    
    // Find article by ID
    const article = mockArticles.find(a => a._id === id);
    
    if (!article) {
      return NextResponse.json(
        { error: 'Article not found' },
        { status: 404 }
      );
    }

    return NextResponse.json(article);
  } catch (error) {
    console.error('Error fetching article:', error);
    return NextResponse.json(
      { error: 'Failed to fetch article' },
      { status: 500 }
    );
  }
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params;
    const body = await request.json();
    
    // Find article by ID
    const articleIndex = mockArticles.findIndex(a => a._id === id);
    
    if (articleIndex === -1) {
      return NextResponse.json(
        { error: 'Article not found' },
        { status: 404 }
      );
    }

    const article = mockArticles[articleIndex];
    
    // Handle different actions
    const { action, ...updateData } = body;
    
    switch (action) {
      case 'approve':
        article.status = 'draft';
        break;
      case 'reject':
        article.status = 'rejected';
        break;
      case 'publish':
        if (article.status === 'rejected') {
          return NextResponse.json(
            { error: 'Cannot publish rejected article' },
            { status: 400 }
          );
        }
        article.status = 'published';
        article.publishedAt = new Date().toISOString();
        break;
      default:
        // Apply general updates
        Object.assign(article, updateData);
    }

    // In a real app, you would save this to your database
    console.log(`Updated article ${id}:`, article);

    return NextResponse.json(article);
  } catch (error) {
    console.error('Error updating article:', error);
    return NextResponse.json(
      { error: 'Failed to update article' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params;
    
    // Find article by ID
    const articleIndex = mockArticles.findIndex(a => a._id === id);
    
    if (articleIndex === -1) {
      return NextResponse.json(
        { error: 'Article not found' },
        { status: 404 }
      );
    }

    // In a real app, you would delete from database
    const deletedArticle = mockArticles.splice(articleIndex, 1)[0];
    console.log(`Deleted article ${id}:`, deletedArticle);

    return NextResponse.json({ message: 'Article deleted successfully' });
  } catch (error) {
    console.error('Error deleting article:', error);
    return NextResponse.json(
      { error: 'Failed to delete article' },
      { status: 500 }
    );
  }
}