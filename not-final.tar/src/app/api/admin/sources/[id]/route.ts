import { NextRequest, NextResponse } from 'next/server';

// Mock sources data - in a real app, this would come from your database
const mockSources = [
  {
    _id: '1',
    name: 'TechCrunch',
    url: 'https://techcrunch.com',
    rssUrls: ['https://techcrunch.com/feed/'],
    active: true,
    categories: ['technology', 'business'],
    lastScraped: '2024-01-15T10:30:00Z',
    lang: 'en'
  },
  {
    _id: '2',
    name: 'BBC News',
    url: 'https://www.bbc.com/news',
    rssUrls: [
      'https://feeds.bbci.co.uk/news/rss.xml',
      'https://feeds.bbci.co.uk/news/technology/rss.xml'
    ],
    active: true,
    categories: ['world', 'politics', 'technology'],
    lastScraped: '2024-01-15T09:15:00Z',
    lang: 'en'
  }
];

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params;
    
    // Find source by ID
    const source = mockSources.find(s => s._id === id);
    
    if (!source) {
      return NextResponse.json(
        { error: 'Source not found' },
        { status: 404 }
      );
    }

    return NextResponse.json(source);
  } catch (error) {
    console.error('Error fetching source:', error);
    return NextResponse.json(
      { error: 'Failed to fetch source' },
      { status: 500 }
    );
  }
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params;
    const body = await request.json();
    
    // Find source by ID
    const sourceIndex = mockSources.findIndex(s => s._id === id);
    
    if (sourceIndex === -1) {
      return NextResponse.json(
        { error: 'Source not found' },
        { status: 404 }
      );
    }

    const source = mockSources[sourceIndex];
    
    // Update source fields
    const updatableFields = ['name', 'url', 'rssUrls', 'active', 'categories', 'lang'];
    
    for (const field of updatableFields) {
      if (body[field] !== undefined) {
        source[field] = body[field];
      }
    }

    // In a real app, you would save this to your database
    console.log(`Updated source ${id}:`, source);

    return NextResponse.json(source);
  } catch (error) {
    console.error('Error updating source:', error);
    return NextResponse.json(
      { error: 'Failed to update source' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params;
    
    // Find source by ID
    const sourceIndex = mockSources.findIndex(s => s._id === id);
    
    if (sourceIndex === -1) {
      return NextResponse.json(
        { error: 'Source not found' },
        { status: 404 }
      );
    }

    // In a real app, you would delete from database
    const deletedSource = mockSources.splice(sourceIndex, 1)[0];
    console.log(`Deleted source ${id}:`, deletedSource);

    return NextResponse.json({ message: 'Source deleted successfully' });
  } catch (error) {
    console.error('Error deleting source:', error);
    return NextResponse.json(
      { error: 'Failed to delete source' },
      { status: 500 }
    );
  }
}