import { NextRequest, NextResponse } from 'next/server';

// Mock data for demonstration - in a real app, this would come from your database
const mockSources = [
  {
    _id: '1',
    name: 'TechCrunch',
    url: 'https://techcrunch.com',
    rssUrls: ['https://techcrunch.com/feed/'],
    active: true,
    categories: ['technology', 'business'],
    lastScraped: '2024-01-15T10:30:00Z',
    lang: 'en'
  },
  {
    _id: '2',
    name: 'BBC News',
    url: 'https://www.bbc.com/news',
    rssUrls: [
      'https://feeds.bbci.co.uk/news/rss.xml',
      'https://feeds.bbci.co.uk/news/technology/rss.xml'
    ],
    active: true,
    categories: ['world', 'politics', 'technology'],
    lastScraped: '2024-01-15T09:15:00Z',
    lang: 'en'
  },
  {
    _id: '3',
    name: 'Reuters',
    url: 'https://www.reuters.com',
    rssUrls: ['https://feeds.reuters.com/reuters/topNews'],
    active: true,
    categories: ['business', 'world'],
    lastScraped: '2024-01-15T08:45:00Z',
    lang: 'en'
  },
  {
    _id: '4',
    name: 'CNN',
    url: 'https://www.cnn.com',
    rssUrls: ['https://rss.cnn.com/rss/cnn_topstories.rss'],
    active: false,
    categories: ['world', 'politics'],
    lastScraped: '2024-01-14T16:20:00Z',
    lang: 'en'
  },
  {
    _id: '5',
    name: 'The Verge',
    url: 'https://www.theverge.com',
    rssUrls: ['https://www.theverge.com/rss/index.xml'],
    active: true,
    categories: ['technology', 'science'],
    lastScraped: '2024-01-15T11:00:00Z',
    lang: 'en'
  }
];

export async function GET(request: NextRequest) {
  try {
    // In a real app, you would:
    // 1. Verify authentication/authorization
    // 2. Connect to your database
    // 3. Fetch sources with proper filtering
    
    const { searchParams } = new URL(request.url);
    const active = searchParams.get('active');
    const category = searchParams.get('category');

    let filteredSources = mockSources;

    // Apply filters
    if (active !== null) {
      filteredSources = filteredSources.filter(source => source.active === (active === 'true'));
    }
    if (category) {
      filteredSources = filteredSources.filter(source => 
        source.categories.includes(category)
      );
    }

    return NextResponse.json(filteredSources);
  } catch (error) {
    console.error('Error fetching sources:', error);
    return NextResponse.json(
      { error: 'Failed to fetch sources' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    // In a real app, you would:
    // 1. Verify authentication/authorization
    // 2. Validate input data
    // 3. Create new source in database
    
    const body = await request.json();
    
    // Validate required fields
    const requiredFields = ['name', 'url', 'rssUrls'];
    for (const field of requiredFields) {
      if (!body[field]) {
        return NextResponse.json(
          { error: `${field} is required` },
          { status: 400 }
        );
      }
    }

    // Validate RSS URLs format
    if (!Array.isArray(body.rssUrls) || body.rssUrls.length === 0) {
      return NextResponse.json(
        { error: 'At least one RSS URL is required' },
        { status: 400 }
      );
    }

    // Create new source (mock)
    const newSource = {
      _id: Date.now().toString(),
      name: body.name,
      url: body.url,
      rssUrls: body.rssUrls,
      active: body.active ?? true,
      categories: body.categories || [],
      lang: body.lang || 'en',
      lastScraped: undefined
    };

    // In a real app, you would save this to your database
    mockSources.push(newSource);

    return NextResponse.json(newSource, { status: 201 });
  } catch (error) {
    console.error('Error creating source:', error);
    return NextResponse.json(
      { error: 'Failed to create source' },
      { status: 500 }
    );
  }
}