import { NextRequest, NextResponse } from 'next/server';

// Mock newsletter subscribers - in a real app, this would come from your database
const mockSubscribers = [
  {
    _id: '1',
    email: 'user1@example.com',
    name: 'John Doe',
    preferences: {
      frequency: 'daily', // daily, weekly, breaking
      categories: ['technology', 'business'],
      format: 'html' // html, text
    },
    active: true,
    subscribedAt: '2024-01-01T10:00:00Z',
    lastSent: '2024-01-15T06:00:00Z'
  },
  {
    _id: '2',
    email: 'user2@example.com',
    name: 'Jane Smith',
    preferences: {
      frequency: 'weekly',
      categories: ['world', 'health'],
      format: 'html'
    },
    active: true,
    subscribedAt: '2024-01-02T14:30:00Z',
    lastSent: '2024-01-14T06:00:00Z'
  },
  {
    _id: '3',
    email: 'user3@example.com',
    name: 'Bob Johnson',
    preferences: {
      frequency: 'breaking',
      categories: ['technology', 'sports'],
      format: 'text'
    },
    active: true,
    subscribedAt: '2024-01-03T09:15:00Z',
    lastSent: '2024-01-15T08:30:00Z'
  }
];

// Mock recent articles for newsletter content
const mockRecentArticles = [
  {
    title: 'Breaking: Major Technology Company Announces Revolutionary AI Breakthrough',
    summary: 'A leading tech company has unveiled a groundbreaking AI technology that promises to transform the industry...',
    url: '/articles/breaking-ai-breakthrough',
    category: 'technology',
    publishedAt: '2024-01-15T10:30:00Z'
  },
  {
    title: 'Global Markets React to Economic Policy Changes',
    summary: 'Financial markets worldwide showed mixed reactions to the latest economic policy announcements...',
    url: '/articles/global-markets-reaction',
    category: 'business',
    publishedAt: '2024-01-15T09:15:00Z'
  },
  {
    title: 'New Study Reveals Surprising Health Benefits of Mediterranean Diet',
    summary: 'Research confirms significant health improvements from traditional Mediterranean eating patterns...',
    url: '/articles/mediterranean-diet-benefits',
    category: 'health',
    publishedAt: '2024-01-14T14:20:00Z'
  }
];

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const action = searchParams.get('action');

    switch (action) {
      case 'subscribers':
        return NextResponse.json({
          subscribers: mockSubscribers,
          total: mockSubscribers.length,
          active: mockSubscribers.filter(s => s.active).length
        });

      case 'preview':
        const frequency = searchParams.get('frequency') || 'daily';
        const categories = searchParams.get('categories')?.split(',') || [];
        
        const preview = generateNewsletterPreview(frequency, categories);
        return NextResponse.json(preview);

      default:
        return NextResponse.json(
          { error: 'Invalid action parameter' },
          { status: 400 }
        );
    }
  } catch (error) {
    console.error('Error in newsletter API:', error);
    return NextResponse.json(
      { error: 'Failed to process newsletter request' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action, ...data } = body;

    switch (action) {
      case 'subscribe':
        return handleSubscription(data);
      
      case 'unsubscribe':
        return handleUnsubscription(data);
      
      case 'send':
        return handleNewsletterSending(data);
      
      case 'test':
        return handleTestEmail(data);
      
      default:
        return NextResponse.json(
          { error: 'Invalid action parameter' },
          { status: 400 }
        );
    }
  } catch (error) {
    console.error('Error in newsletter API:', error);
    return NextResponse.json(
      { error: 'Failed to process newsletter request' },
      { status: 500 }
    );
  }
}

function handleSubscription(data: any) {
  const { email, name, preferences } = data;

  // Validate required fields
  if (!email || !name) {
    return NextResponse.json(
      { error: 'Email and name are required' },
      { status: 400 }
    );
  }

  // Check if already subscribed
  const existingSubscriber = mockSubscribers.find(s => s.email === email);
  if (existingSubscriber) {
    return NextResponse.json(
      { error: 'Email already subscribed' },
      { status: 400 }
    );
  }

  // Create new subscriber
  const newSubscriber = {
    _id: Date.now().toString(),
    email,
    name,
    preferences: {
      frequency: preferences?.frequency || 'daily',
      categories: preferences?.categories || [],
      format: preferences?.format || 'html'
    },
    active: true,
    subscribedAt: new Date().toISOString(),
    lastSent: null
  };

  mockSubscribers.push(newSubscriber);

  // In a real app, you would:
  // 1. Save to database
  // 2. Send confirmation email
  // 3. Set up welcome sequence

  return NextResponse.json({
    message: 'Successfully subscribed to newsletter',
    subscriber: newSubscriber
  }, { status: 201 });
}

function handleUnsubscription(data: any) {
  const { email } = data;

  if (!email) {
    return NextResponse.json(
      { error: 'Email is required' },
      { status: 400 }
    );
  }

  const subscriberIndex = mockSubscribers.findIndex(s => s.email === email);
  if (subscriberIndex === -1) {
    return NextResponse.json(
      { error: 'Email not found in subscriber list' },
      { status: 404 }
    );
  }

  mockSubscribers[subscriberIndex].active = false;

  // In a real app, you would:
  // 1. Update database
  // 2. Send confirmation email
  // 3. Log the unsubscription

  return NextResponse.json({
    message: 'Successfully unsubscribed from newsletter'
  });
}

function handleNewsletterSending(data: any) {
  const { frequency = 'daily', categories = [] } = data;

  // Get subscribers for this frequency and categories
  const targetSubscribers = mockSubscribers.filter(subscriber => {
    if (!subscriber.active) return false;
    if (subscriber.preferences.frequency !== frequency) return false;
    if (categories.length > 0) {
      const hasMatchingCategory = categories.some((cat: string) => 
        subscriber.preferences.categories.includes(cat)
      );
      if (!hasMatchingCategory) return false;
    }
    return true;
  });

  // Generate newsletter content
  const newsletterContent = generateNewsletterContent(frequency, categories);

  // In a real app, you would:
  // 1. Send emails to all target subscribers
  // 2. Track delivery status
  // 3. Update lastSent timestamp
  // 4. Log the sending activity

  const results = {
    sent: targetSubscribers.length,
    content: newsletterContent,
    timestamp: new Date().toISOString(),
    frequency,
    categories
  };

  return NextResponse.json({
    message: `Newsletter sent to ${targetSubscribers.length} subscribers`,
    results
  });
}

function handleTestEmail(data: any) {
  const { email, frequency = 'daily', categories = [] } = data;

  if (!email) {
    return NextResponse.json(
      { error: 'Email is required' },
      { status: 400 }
    );
  }

  // Generate test newsletter content
  const newsletterContent = generateNewsletterContent(frequency, categories);

  // In a real app, you would:
  // 1. Send test email to the specified address
  // 2. Use a test template
  // 3. Log the test email

  return NextResponse.json({
    message: `Test newsletter sent to ${email}`,
    preview: newsletterContent
  });
}

function generateNewsletterContent(frequency: string, categories: string[]) {
  const date = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  let filteredArticles = mockRecentArticles;
  if (categories.length > 0) {
    filteredArticles = mockRecentArticles.filter(article => 
      categories.includes(article.category)
    );
  }

  const subject = frequency === 'breaking' 
    ? '🚨 Breaking News Alert'
    : frequency === 'weekly'
    ? `📰 Weekly News Digest - ${date}`
    : `📬 Daily News Briefing - ${date}`;

  const content = {
    subject,
    html: `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>${subject}</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .header { background: #f8f9fa; padding: 20px; text-align: center; }
          .content { padding: 20px; }
          .article { margin-bottom: 30px; padding-bottom: 20px; border-bottom: 1px solid #eee; }
          .article:last-child { border-bottom: none; }
          .article h3 { margin: 0 0 10px 0; color: #2563eb; }
          .article p { margin: 0 0 10px 0; }
          .article a { color: #2563eb; text-decoration: none; }
          .article a:hover { text-decoration: underline; }
          .category { background: #e5e7eb; padding: 2px 8px; border-radius: 12px; font-size: 12px; }
          .footer { background: #f8f9fa; padding: 20px; text-align: center; font-size: 12px; color: #666; }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>NewsHub Newsletter</h1>
          <p>${date}</p>
        </div>
        <div class="content">
          ${filteredArticles.map(article => `
            <div class="article">
              <h3><a href="${article.url}">${article.title}</a></h3>
              <p>${article.summary}</p>
              <span class="category">${article.category}</span>
            </div>
          `).join('')}
        </div>
        <div class="footer">
          <p>You're receiving this email because you subscribed to NewsHub's ${frequency} newsletter.</p>
          <p>
            <a href="/unsubscribe?email=user@example.com">Unsubscribe</a> | 
            <a href="/preferences">Manage Preferences</a>
          </p>
        </div>
      </body>
      </html>
    `,
    text: `
NewsHub Newsletter - ${date}

${filteredArticles.map(article => `
${article.title}
${article.summary}
Read more: ${article.url}
Category: ${article.category}
---
`).join('')}

You're receiving this email because you subscribed to NewsHub's ${frequency} newsletter.

Unsubscribe: /unsubscribe?email=user@example.com
Manage Preferences: /preferences
    `
  };

  return content;
}

function generateNewsletterPreview(frequency: string, categories: string[]) {
  const content = generateNewsletterContent(frequency, categories);
  
  return {
    subject: content.subject,
    articles: mockRecentArticles.filter(article => 
      categories.length === 0 || categories.includes(article.category)
    ),
    estimatedRecipients: mockSubscribers.filter(s => {
      if (!s.active) return false;
      if (s.preferences.frequency !== frequency) return false;
      if (categories.length > 0) {
        return categories.some(cat => s.preferences.categories.includes(cat));
      }
      return true;
    }).length
  };
}