# NewsHub Deployment Guide

## Overview

NewsHub is a modern, AI-powered news platform built with Next.js, Node.js, MongoDB, and Redis. This guide provides comprehensive instructions for deploying and maintaining the application in production.

## Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Nginx         │    │   Frontend      │    │   Backend       │
│   (Reverse      │◄───┤   (Next.js)     │◄───┤   (Node.js)     │
│    Proxy)       │    │                 │    │                 │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Monitoring    │    │   MongoDB       │    │   Redis         │
│   (Prometheus/  │    │   (Database)    │    │   (Cache/Queue) │
│    Grafana)     │    │                 │    │                 │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

## Prerequisites

### System Requirements
- **OS**: Ubuntu 20.04+ or CentOS 8+
- **RAM**: Minimum 4GB, Recommended 8GB+
- **CPU**: Minimum 2 cores, Recommended 4 cores+
- **Storage**: Minimum 50GB SSD, Recommended 100GB+
- **Network**: Stable internet connection

### Software Requirements
- Docker and Docker Compose
- Git
- SSL/TLS certificates (Let's Encrypt recommended)
- Domain name (e.g., newshub.com)

### Environment Variables
Create a `.env` file in the project root:

```bash
# Application
NODE_ENV=production
NEXT_TELEMETRY_DISABLED=1
NEXT_PUBLIC_API_URL=https://api.newshub.com

# Database
MONGO_ROOT_USERNAME=your_mongo_user
MONGO_ROOT_PASSWORD=your_mongo_password
MONGODB_URI=mongodb://newshub-mongo:27017/newshub_prod?authSource=admin

# Redis
REDIS_PASSWORD=your_redis_password
REDIS_URL=redis://:your_redis_password@newshub-redis:6379

# Security
JWT_SECRET=your_super_secure_jwt_secret_min_32_chars
ZAI_API_KEY=your_z_ai_api_key

# Monitoring
GRAFANA_PASSWORD=your_grafana_password

# SSL (optional, for direct SSL termination)
SSL_CERT_PATH=/path/to/your/cert.crt
SSL_KEY_PATH=/path/to/your/private.key
```

## Deployment Methods

### Method 1: Docker Compose (Recommended)

#### 1. Clone the Repository
```bash
git clone https://github.com/your-username/newshub.git
cd newshub
```

#### 2. Set Up Environment Variables
```bash
cp .env.example .env
# Edit .env with your actual values
```

#### 3. Build and Deploy
```bash
# Build all services
docker-compose build

# Start all services
docker-compose up -d

# Check status
docker-compose ps
docker-compose logs
```

#### 4. Set Up SSL Certificates
```bash
# Install Certbot
sudo apt update
sudo apt install certbot python3-certbot-nginx

# Obtain certificates
sudo certbot --nginx -d newshub.com -d www.newshub.com

# Test auto-renewal
sudo certbot renew --dry-run
```

#### 5. Verify Deployment
```bash
# Check health endpoints
curl https://newshub.com/health
curl https://api.newshub.com/health

# Check monitoring
curl http://localhost:9090/targets  # Prometheus
curl http://localhost:3001/api/health  # Grafana
```

### Method 2: Kubernetes

#### 1. Prepare Kubernetes Cluster
```bash
# Create namespace
kubectl create namespace newshub

# Create secrets
kubectl create secret generic newshub-secrets \
  --from-literal=jwt-secret=your_jwt_secret \
  --from-literal=mongo-root-password=your_mongo_password \
  --from-literal=redis-password=your_redis_password \
  --namespace=newshub
```

#### 2. Deploy Components
```bash
# Deploy database
kubectl apply -f k8s/mongodb-deployment.yaml
kubectl apply -f k8s/redis-deployment.yaml

# Deploy application
kubectl apply -f k8s/backend-deployment.yaml
kubectl apply -f k8s/frontend-deployment.yaml

# Deploy ingress and monitoring
kubectl apply -f k8s/ingress.yaml
kubectl apply -f k8s/monitoring.yaml
```

#### 3. Verify Deployment
```bash
kubectl get pods -n newshub
kubectl get services -n newshub
kubectl get ingress -n newshub
```

### Method 3: Cloud Deployment

#### AWS ECS
1. **Build and Push Images**
```bash
# Build and push to ECR
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin 123456789012.dkr.ecr.us-east-1.amazonaws.com
docker build -t newshub-frontend .
docker tag newshub-frontend:latest 123456789012.dkr.ecr.us-east-1.amazonaws.com/newshub-frontend:latest
docker push 123456789012.dkr.ecr.us-east-1.amazonaws.com/newshub-frontend:latest
```

2. **Deploy using ECS Task Definitions**
```bash
# Create task definitions
aws ecs register-task-definition --family newshub-frontend --cli-input-json file://task-definitions/frontend.json
aws ecs register-task-definition --family newshub-backend --cli-input-json file://task-definitions/backend.json

# Create service
aws ecs create-service --cluster newshub-cluster --service-name newshub-frontend --task-definition newshub-frontend:1 --desired-count 2 --launch-type FARGATE
```

#### Google Cloud Run
```bash
# Build and deploy
gcloud builds submit --tag gcr.io/PROJECT_ID/newshub-frontend
gcloud run deploy newshub-frontend --image gcr.io/PROJECT_ID/newshub-frontend --platform managed
```

## Monitoring and Maintenance

### Health Checks

#### Application Health
```bash
# Frontend health
curl https://newshub.com/health

# Backend health
curl https://api.newshub.com/health

# Database health
docker exec newshub-mongo mongosh --eval 'db.hello()'

# Redis health
docker exec newshub-redis redis-cli ping
```

#### Monitoring Dashboards
- **Prometheus**: http://localhost:9090
- **Grafana**: http://localhost:3001 (admin: your_grafana_password)
- **Kibana**: http://localhost:5601 (for logs)

### Log Management

#### View Logs
```bash
# Frontend logs
docker-compose logs -f frontend

# Backend logs
docker-compose logs -f backend

# Nginx logs
docker-compose logs -f nginx

# MongoDB logs
docker-compose logs -f mongo

# Redis logs
docker-compose logs -f redis
```

#### Centralized Logging with ELK
1. **Access Kibana**: http://localhost:5601
2. **Create Index Pattern**: `newshub-*`
3. **View Logs**: Discover tab

### Backup and Recovery

#### Database Backup
```bash
# Create backup
docker exec newshub-mongo mongodump --out /tmp/backup --username newshub --password your_password

# Copy backup to host
docker cp newshub-mongo:/tmp/backup ./backup

# Compress backup
tar -czf backup-$(date +%Y%m%d).tar.gz backup/

# Upload to cloud storage (optional)
aws s3 cp backup-$(date +%Y%m%d).tar.gz s3://your-backup-bucket/
```

#### Database Recovery
```bash
# Copy backup to container
docker cp ./backup newshub-mongo:/tmp/backup

# Restore backup
docker exec newshub-mongo mongorestore /tmp/backup --username newshub --password your_password
```

### Scaling

#### Horizontal Scaling
```bash
# Scale frontend
docker-compose up -d --scale frontend=3

# Scale backend
docker-compose up -d --scale backend=3

# Scale workers
docker-compose up -d --scale worker=2
```

#### Vertical Scaling
Update `docker-compose.yml` to increase resource limits:
```yaml
services:
  frontend:
    deploy:
      resources:
        limits:
          cpus: '2.0'
          memory: 4G
        reservations:
          cpus: '1.0'
          memory: 2G
```

### Security Updates

#### Regular Updates
```bash
# Update Docker images
docker-compose pull
docker-compose up -d

# Update system packages
sudo apt update && sudo apt upgrade -y

# Update Docker
sudo apt install docker-ce docker-ce-cli containerd.io
```

#### Security Scanning
```bash
# Scan for vulnerabilities
docker scan newshub-frontend
docker scan newshub-backend

# Run security audit
npm audit
cd backend && npm audit
```

## Troubleshooting

### Common Issues

#### 1. Container Not Starting
```bash
# Check logs
docker-compose logs [service-name]

# Check resource usage
docker stats

# Restart service
docker-compose restart [service-name]
```

#### 2. Database Connection Issues
```bash
# Check database status
docker exec newshub-mongo mongosh --eval 'db.hello()'

# Check network connectivity
docker exec newshub-backend ping newshub-mongo

# Verify connection string
echo $MONGODB_URI
```

#### 3. High Memory Usage
```bash
# Check memory usage
docker stats --format "table {{.Container}}\t{{.MemUsage}}"

# Restart memory-intensive services
docker-compose restart frontend backend

# Increase memory limits in docker-compose.yml
```

#### 4. SSL Certificate Issues
```bash
# Check certificate status
sudo certbot certificates

# Renew certificates
sudo certbot renew

# Test SSL configuration
openssl s_client -connect newshub.com:443 -servername newshub.com
```

### Performance Optimization

#### Caching
```bash
# Clear Redis cache
docker exec newshub-redis redis-cli FLUSHALL

# Check Redis memory usage
docker exec newshub-redis redis-cli INFO memory

# Optimize MongoDB indexes
docker exec newshub-mongo mongosh --eval 'db.articles.getIndexes()'
```

#### Database Optimization
```bash
# Create MongoDB indexes
docker exec newshub-mongo mongosh newshub_prod --eval 'db.articles.createIndex({status: 1, publishedAt: -1})'

# Optimize queries
docker exec newshub-mongo mongosh newshub_prod --eval 'db.articles.explain("executionStats").find({status: "published"})'
```

## Disaster Recovery

### Backup Strategy
1. **Daily automated backups** of database and media files
2. **Weekly full backups** stored off-site
3. **Real-time replication** for critical data
4. **Version control** for configuration files

### Recovery Procedures
1. **Assess the impact** and determine recovery scope
2. **Restore from backups** in reverse chronological order
3. **Verify data integrity** and application functionality
4. **Monitor system performance** post-recovery
5. **Document the incident** and improve procedures

### Rollback Plan
```bash
# Rollback to previous version
git checkout [previous-tag]
docker-compose build
docker-compose up -d

# Restore database from backup
docker exec newshub-mongo mongorestore /tmp/backup --username newshub --password your_password
```

## Support and Maintenance

### Regular Tasks
- **Daily**: Monitor system health and performance metrics
- **Weekly**: Review logs, update security patches, backup verification
- **Monthly**: Database optimization, capacity planning, security audits
- **Quarterly**: Performance tuning, infrastructure upgrades, cost optimization

### Contact Information
- **Emergency Support**: support@newshub.com
- **Technical Documentation**: docs.newshub.com
- **Status Page**: status.newshub.com
- **GitHub Issues**: github.com/your-username/newshub/issues

## Conclusion

This deployment guide provides a comprehensive overview of deploying and maintaining NewsHub in production. Following these procedures will ensure a stable, secure, and performant deployment of the application.

For additional support or questions, please refer to the documentation or contact the support team.